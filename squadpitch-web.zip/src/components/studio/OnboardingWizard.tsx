'use client';

import { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { useQueryClient } from '@tanstack/react-query';
import {
  ArrowRight,
  Loader2,
  Check,
  Sparkles,
  Globe,
  MessageSquare,
  Zap,
  Calendar,
  CheckCircle2,
  Upload,
  FileText,
  X,
  Pencil,
  Database,
  SlidersHorizontal,
  ChevronRight,
  Home,
  Car,
  Building2,
  ShoppingBag,
  Landmark,
  Shield,
  Scale,
  TrendingUp,
  Wrench,
  Dumbbell,
  UtensilsCrossed,
  Scissors,
  Mic,
  Store,
  Briefcase,
  type LucideIcon,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  useOnboardingUploadDocuments,
  useCreateClient,
  useGenerateContent,
  useChannelConnections,
  useIndustries,
  useZillowExtract,
  useLicenseLookup,
  useCrmAnalyze,
  resolveBusinessDataLabels,
  squadpitchKeys,
  type Channel,
  type Draft,
  type OnboardingAnalyzeResult,
  type OnboardingDataItem,
  type IndustryProfile,
  type OnboardingBrandData,
  type AgentProfileDraft,
} from '@/hooks/useSquadpitch';
import { apiFetch } from '@/lib/apiFetch';
import { StatusBanner } from '@/components/common/StatusBanner';
import { OnboardingPostCard } from '@/components/studio/OnboardingPostCard';
import { RealEstateSourceCard } from '@/components/studio/RealEstateSourceCard';
import { AgentProfileConfirmation } from '@/components/studio/AgentProfileConfirmation';
import { OnboardingChannelConnect } from '@/components/studio/onboarding/OnboardingChannelConnect';
import { OnboardingTechStack } from '@/components/studio/onboarding/OnboardingTechStack';
import { buildOnboardingGenerationPlan } from '@/lib/assistant/onboardingPlanner';

function slugify(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 64);
}

const INDUSTRY_ICON_MAP: Record<string, LucideIcon> = {
  Home,
  Car,
  Building2,
  ShoppingBag,
  Landmark,
  Shield,
  Scale,
  TrendingUp,
  Wrench,
  Dumbbell,
  UtensilsCrossed,
  Scissors,
  Mic,
  Store,
  Briefcase,
};

const ALL_CHANNELS: { id: Channel; label: string }[] = [
  { id: 'INSTAGRAM', label: 'Instagram' },
  { id: 'TIKTOK', label: 'TikTok' },
  { id: 'LINKEDIN', label: 'LinkedIn' },
  { id: 'X', label: 'X' },
  { id: 'FACEBOOK', label: 'Facebook' },
  { id: 'YOUTUBE', label: 'YouTube' },
];

const TONE_OPTIONS = [
  { id: 'professional', label: 'Professional' },
  { id: 'conversational', label: 'Conversational' },
  { id: 'bold', label: 'Bold' },
];

const GOAL_OPTIONS = [
  { id: 'growth', label: 'Growth', icon: Sparkles },
  { id: 'engagement', label: 'Engagement', icon: MessageSquare },
  { id: 'leads', label: 'Leads', icon: Zap },
] as const;

const CHANNEL_COLORS: Record<string, { badge: string; bg: string }> = {
  INSTAGRAM: { badge: 'bg-pink-500/20 text-pink-400', bg: 'from-pink-500/5' },
  TIKTOK:    { badge: 'bg-cyan-500/20 text-cyan-400', bg: 'from-cyan-500/5' },
  X:         { badge: 'bg-white-20 text-white-60',       bg: 'from-white-5' },
  LINKEDIN:  { badge: 'bg-blue-500/20 text-blue-400', bg: 'from-blue-500/5' },
  FACEBOOK:  { badge: 'bg-blue-600/20 text-blue-300', bg: 'from-blue-600/5' },
  YOUTUBE:   { badge: 'bg-red-500/20 text-red-400',   bg: 'from-red-500/5' },
};

const PREVIEW_DAYS = ['Monday', 'Wednesday', 'Friday'] as const;

const INDUSTRY_PREVIEW_CONTENT: Record<string, { title: string; snippet: string; channel: string }[]> = {
  real_estate: [
    { title: '\u{1F3E1} Just Listed in Austin \u2014 3 Bed Home on Maple Ave for $425K', snippet: 'Open layout, updated kitchen, huge backyard. Open house this Saturday 1\u20134pm. DM for details.', channel: 'Instagram' },
    { title: '\u{1F4CD} Living in Westlake Hills \u2014 What Buyers Should Know', snippet: 'Top schools, walkable parks, and homes still under $500K. Here\u2019s why families are moving here.', channel: 'Facebook' },
    { title: '\u{1F4C5} Open House This Weekend \u2014 Don\u2019t Miss It', snippet: '"We found our dream home in 3 weeks." See how we helped the Johnsons close on their first home.', channel: 'LinkedIn' },
  ],
  car_sales: [
    { title: '\u{1F697} 2024 Toyota RAV4 XLE \u2014 Just Arrived, 12K Miles', snippet: 'One owner, loaded with safety features. Starting at $28,900. Schedule your test drive today.', channel: 'Instagram' },
    { title: '\u{1F525} Limited-Time Offer \u2014 Save $2,000 This Week', snippet: 'Memorial Day Sale \u2014 0% APR on all new inventory this weekend only. Don\u2019t wait.', channel: 'Facebook' },
    { title: '\u2B50 Why Drivers Love the 2023 Honda CR-V', snippet: 'Certified pre-owned, financing from $299/mo. 4.9 stars from 180+ buyer reviews.', channel: 'LinkedIn' },
  ],
  property_management: [
    { title: '\u{1F3E2} Now Leasing \u2014 2BR Downtown, $1,850/mo', snippet: 'In-unit laundry, rooftop access, pet-friendly. Tour available this week.', channel: 'Instagram' },
    { title: '\u2B50 Resident Spotlight \u2014 95% Renewal Rate', snippet: '"Best management company we\u2019ve worked with." See why tenants stay year after year.', channel: 'Facebook' },
    { title: '\u{1F527} 5 Things Every Tenant Should Check Before Winter', snippet: 'Protect your unit and avoid costly repairs. Quick checklist inside.', channel: 'LinkedIn' },
  ],
  ecommerce: [
    { title: '\u{1F381} New Arrival \u2014 Wireless Earbuds, 40hr Battery, Under $60', snippet: 'Noise canceling, one-touch pairing, 4.8 stars. Free shipping today only.', channel: 'Instagram' },
    { title: '\u2B50 Customer Favorite \u2014 2,300+ Five-Star Reviews', snippet: '"These changed my morning routine." See what everyone\u2019s talking about.', channel: 'Facebook' },
    { title: '\u{1F525} Flash Sale \u2014 30% Off All Summer Essentials', snippet: 'Use code SUMMER30 at checkout. Ends Friday at midnight.', channel: 'LinkedIn' },
  ],
  legal: [
    { title: '\u2696\uFE0F What to Do After a Car Accident in Ohio', snippet: '3 things you should never say \u2014 and what to do instead. Free consultation available.', channel: 'LinkedIn' },
    { title: '\u{1F4D8} 3 Legal Mistakes That Can Hurt Your Case', snippet: 'DIY estate planning? Here are 5 mistakes that could cost your family thousands.', channel: 'Facebook' },
    { title: '\u2705 When It\u2019s Time to Call an Attorney', snippet: 'Not sure if you have a case? Here are the signs you need legal representation.', channel: 'Instagram' },
  ],
  fitness: [
    { title: '\u{1F4AA} 3 Exercises to Build Strength Faster', snippet: 'The #1 mistake killing your bench press gains \u2014 and the simple fix that works immediately.', channel: 'Instagram' },
    { title: '\u{1F525} Client Spotlight: 8 Weeks of Progress', snippet: '"Down 35 lbs in 4 months." See how Sarah transformed her health with our 12-week program.', channel: 'Facebook' },
    { title: '\u{1F3CB}\uFE0F New Member Special \u2014 50% Off First Month', snippet: 'Personal training, group classes, and nutrition coaching. Limited spots available.', channel: 'LinkedIn' },
  ],
  restaurant: [
    { title: '\u{1F37D}\uFE0F Today\u2019s Special \u2014 Pan-Seared Salmon', snippet: 'Lemon butter, roasted vegetables, garlic mashed potatoes. Dine-in only tonight.', channel: 'Instagram' },
    { title: '\u{1F95D} Weekend Brunch \u2014 Bottomless Mimosas', snippet: 'New avocado toast menu + bottomless mimosas. Every Saturday & Sunday 10am\u20132pm.', channel: 'Facebook' },
    { title: '\u2B50 Rated #1 on Google \u2014 See Why', snippet: '"Best Italian food outside of Italy." 4.9 stars from 500+ reviews in the neighborhood.', channel: 'LinkedIn' },
  ],
  mortgage: [
    { title: '\u{1F4C9} Rates Just Dropped to 6.25%', snippet: 'Is now the right time to refinance? Free rate check in 2 minutes. No commitment.', channel: 'LinkedIn' },
    { title: '\u{1F3E0} First-Time Buyer? Read This First', snippet: '3 things every first-time buyer should know before applying for a mortgage. Free guide inside.', channel: 'Facebook' },
    { title: '\u{1F4B0} "They Saved Us $400/Month"', snippet: 'See how we help families lower their mortgage payments. Free consultation.', channel: 'Instagram' },
  ],
  insurance: [
    { title: '\u{1F3E0} Is Your Home Underinsured?', snippet: '60% of homeowners are. Get a free coverage review today \u2014 takes 5 minutes.', channel: 'Facebook' },
    { title: '\u{1F4B5} Bundle & Save Up to 25%', snippet: 'Home + auto bundle. Most quotes take under 5 minutes. No obligation.', channel: 'LinkedIn' },
    { title: '\u26C8\uFE0F Storm Season Starts June 1', snippet: 'Your 5-step checklist to protect your home and family before hurricane season.', channel: 'Instagram' },
  ],
  finance: [
    { title: '\u{1F4CA} 3 Deductions Most Business Owners Miss', snippet: 'Could save you $5,000+ this year. Here\u2019s what your accountant might not tell you.', channel: 'LinkedIn' },
    { title: '\u{1F4B0} Think You Can\u2019t Retire Early?', snippet: 'Here\u2019s the simple math that changes everything. Free retirement calculator inside.', channel: 'Facebook' },
    { title: '\u2B50 "They Found $12K in Savings"', snippet: 'See how we optimize finances for business owners. Free consultation available.', channel: 'Instagram' },
  ],
  home_services: [
    { title: '\u{1F3E0} Before & After \u2014 Kitchen Transformation', snippet: 'From dated to stunning in just 3 weeks. Swipe to see the full transformation.', channel: 'Instagram' },
    { title: '\u{1F527} Spring HVAC Checklist', snippet: '4 things to do now to avoid a $2,000 repair this summer. Takes 15 minutes.', channel: 'Facebook' },
    { title: '\u2B50 200+ Homeowners Trust Us', snippet: '"On time, on budget, and the work was flawless." See our latest 5-star reviews.', channel: 'LinkedIn' },
  ],
  beauty: [
    { title: '\u2728 New \u2014 Keratin Smoothing Treatment', snippet: 'Silky, frizz-free hair for up to 12 weeks. Book your consultation today.', channel: 'Instagram' },
    { title: '\u{1F485} Client Glow-Up \u2014 Balayage Transformation', snippet: 'From grown-out roots to dimensional balayage. Swipe to see the before & after.', channel: 'Facebook' },
    { title: '\u{1F4C5} Holiday Appointments Filling Fast', snippet: 'Book your color + cut before December 15. Limited availability remaining.', channel: 'LinkedIn' },
  ],
  creator: [
    { title: '\u{1F3AC} 30 Days of Content in One Afternoon', snippet: 'Here\u2019s my exact workflow for batch-creating a full month of posts. Save this.', channel: 'Instagram' },
    { title: '\u{1F680} New Course \u2014 Grow to 10K Followers', snippet: 'Early bird pricing ends Friday. 500+ students enrolled already.', channel: 'LinkedIn' },
    { title: '\u{1F4AC} What\u2019s Your #1 Tool?', snippet: 'Drop it below \u2014 I\u2019ll share my top 5 tomorrow. Let\u2019s compare notes.', channel: 'Facebook' },
  ],
  small_business: [
    { title: '\u{1F389} Grand Opening \u2014 20% Off Everything', snippet: 'We\u2019re officially open! Stop by this weekend for discounts + free samples.', channel: 'Instagram' },
    { title: '\u{1F44B} Meet Sarah, Our Lead Designer', snippet: '10 years of experience and a passion for detail. Learn why clients love working with her.', channel: 'Facebook' },
    { title: '\u2B50 100+ Five-Star Reviews', snippet: '"Best local shop in town." Thank you for the love \u2014 we couldn\u2019t do it without you.', channel: 'LinkedIn' },
  ],
  other: [
    { title: '\u{1F4A1} Here\u2019s What Makes Us Different', snippet: 'We help businesses grow with tailored solutions. See our approach in action.', channel: 'LinkedIn' },
    { title: '\u2B50 Client Spotlight \u2014 Exceeding Expectations', snippet: '"They exceeded every expectation." See how we helped this client achieve their goals.', channel: 'Facebook' },
    { title: '\u{1F3AC} A Day Behind the Scenes', snippet: 'The people, the process, and the passion behind the work. Take a look inside.', channel: 'Instagram' },
  ],
};

const DEFAULT_PREVIEW_CONTENT = INDUSTRY_PREVIEW_CONTENT.small_business;

type SetupStage = 'uploading' | 'analyzing' | 'extracting' | 'extractingData' | 'importing' | 'workspace' | 'generating';

type StageStatus = 'pending' | 'active' | 'done';

interface StageState {
  uploading: StageStatus | 'skipped';
  analyzing: StageStatus;
  extracting: StageStatus;
  extractingData: StageStatus | 'skipped';
  importing: StageStatus | 'skipped';
  workspace: StageStatus;
  generating: StageStatus;
  postsGenerated: number;
  dataItemsImported: number;
}

interface CrawlPage {
  url: string;
  title: string;
  pageNum: number;
  totalExpected: number;
}

const ACCEPTED_FILE_TYPES = '.pdf,.docx,.txt,.csv';
const MAX_FILES = 5;

function isUrl(value: string): boolean {
  const trimmed = value.trim();
  if (/^https?:\/\//i.test(trimmed)) return true;
  if (/^[a-z0-9]([a-z0-9-]*[a-z0-9])?\.[a-z]{2,}/i.test(trimmed) && !trimmed.includes(' ')) return true;
  return false;
}

function normalizeUrl(value: string): string {
  const trimmed = value.trim();
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  return `https://${trimmed}`;
}

// ── SSE stream consumer ─────────────────────────────────────────────────

interface StreamCallbacks {
  onCrawlPage: (page: CrawlPage) => void;
  onCrawlDone: () => void;
  onBrandDone: (brandData: OnboardingBrandData) => void;
  onDataProgress: (items: OnboardingDataItem[], count: number) => void;
  onDataDone: (items: OnboardingDataItem[], count: number) => void;
  onError: (message: string) => void;
}

async function consumeAnalyzeStream(
  body: { input: string; inputType: string; documentTexts?: string[]; industryKey?: string; agentProfileDraft?: AgentProfileDraft },
  callbacks: Omit<StreamCallbacks, 'onDone'>,
): Promise<OnboardingAnalyzeResult | null> {
  const res = await fetch('/api/proxy/onboarding/analyze-stream', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });

  if (!res.ok || !res.body) {
    callbacks.onError('Failed to connect to analysis service.');
    return null;
  }

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let finalResult: OnboardingAnalyzeResult | null = null;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() || ''; // keep incomplete line in buffer

    for (const line of lines) {
      if (!line.startsWith('data: ')) continue;
      try {
        const data = JSON.parse(line.slice(6));
        switch (data.event) {
          case 'crawl:page':
            callbacks.onCrawlPage(data as CrawlPage);
            break;
          case 'crawl:discovered':
            // total expected updated via crawl:page
            break;
          case 'crawl:done':
            callbacks.onCrawlDone();
            break;
          case 'brand:done':
            callbacks.onBrandDone({ ...data.brandData, logoUrl: data.logoUrl || undefined });
            break;
          case 'data:progress':
            callbacks.onDataProgress(data.items || [], data.count || 0);
            break;
          case 'data:done':
            callbacks.onDataDone(data.items || [], data.count || 0);
            break;
          case 'done':
            finalResult = data as OnboardingAnalyzeResult;
            break;
          case 'error':
            callbacks.onError(data.message || 'Analysis failed.');
            break;
        }
      } catch {
        // skip malformed event
      }
    }
  }

  return finalResult;
}

// ── Component ───────────────────────────────────────────────────────────

export function OnboardingWizard() {
  const router = useRouter();
  const [step, setStep] = useState<0 | 1 | 2 | 3 | 4>(0);

  // Industry profiles
  const { data: industries = [] } = useIndustries();
  const [selectedIndustry, setSelectedIndustry] = useState<string | null>(null);
  const activeProfile = industries.find((p) => p.key === selectedIndustry) ?? null;
  const bdLabels = resolveBusinessDataLabels(activeProfile?.businessDataLabels);

  // Resolved industry-specific onboarding step labels (with defaults)
  const industrySteps = activeProfile?.onboardingSteps ?? {
    explore: 'Exploring your website...',
    understand: 'Understanding your brand...',
    insights: 'Discovering business insights...',
    prepare: 'Preparing your workspace...',
    generate: 'Creating your first posts...',
  };

  // Step 1 state
  const [input, setInput] = useState('');
  const [description, setDescription] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Step 2 state — AI results
  const [analyzeResult, setAnalyzeResult] = useState<OnboardingAnalyzeResult | null>(null);
  const [createdClientId, setCreatedClientId] = useState<string | null>(null);
  const [generatedDrafts, setGeneratedDrafts] = useState<Draft[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [stages, setStages] = useState<StageState>({
    uploading: 'pending',
    analyzing: 'pending',
    extracting: 'pending',
    extractingData: 'pending',
    importing: 'pending',
    workspace: 'pending',
    generating: 'pending',
    postsGenerated: 0,
    dataItemsImported: 0,
  });

  // Live crawl progress
  const [crawlPages, setCrawlPages] = useState<CrawlPage[]>([]);
  const [crawlDone, setCrawlDone] = useState(false);
  const [uploadedDocNames, setUploadedDocNames] = useState<string[]>([]);
  const [extractedDataItems, setExtractedDataItems] = useState<OnboardingDataItem[]>([]);
  const [earlyBrandData, setEarlyBrandData] = useState<OnboardingBrandData | null>(null);

  // User-modifiable options (populated from AI, changeable before profiles are saved)
  const [selectedTone, setSelectedTone] = useState('');
  const [selectedGoal, setSelectedGoal] = useState('');
  const [selectedChannels, setSelectedChannels] = useState<Channel[]>([]);

  // RE-specific onboarding sources
  const [reSourceDrafts, setReSourceDrafts] = useState<AgentProfileDraft[]>([]);
  const [mergedDraft, setMergedDraft] = useState<AgentProfileDraft | null>(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [zillowUrl, setZillowUrl] = useState('');
  const [licenseState, setLicenseState] = useState('');
  const [licenseNumber, setLicenseNumber] = useState('');
  const [crmFile, setCrmFile] = useState<File | null>(null);
  const [reSourceLoading, setReSourceLoading] = useState<string | null>(null);
  const [reSourceError, setReSourceError] = useState<string | null>(null);

  // Step 3 state — Content preview bulk actions
  const [bulkActionRunning, setBulkActionRunning] = useState(false);
  const [bulkSuccess, setBulkSuccess] = useState(false);
  const [bulkError, setBulkError] = useState<string | null>(null);
  const [channelFilter, setChannelFilter] = useState<string | null>(null);
  const [generatingMore, setGeneratingMore] = useState(false);
  const [templateLabels, setTemplateLabels] = useState<string[]>([]);

  // Connected channels from Step 2
  const [connectedChannelsList, setConnectedChannelsList] = useState<Channel[]>([]);

  // Track if setup is running to prevent double-click
  const setupRunning = useRef(false);
  const importedDataItemIds = useRef<string[]>([]);

  // Channel connections — for Step 2 publish flow
  const queryClient = useQueryClient();
  const connections = useChannelConnections(createdClientId ?? undefined);
  const hasConnectedChannel = (connections.data ?? []).some((c) => c.status === 'CONNECTED');

  // Mutations
  const uploadDocuments = useOnboardingUploadDocuments();
  const createClient = useCreateClient();
  const generate = useGenerateContent();
  const zillowExtract = useZillowExtract();
  const licenseLookupMutation = useLicenseLookup();
  const crmAnalyzeMutation = useCrmAnalyze();

  const isRealEstate = selectedIndustry === 'real_estate';
  const hasBusinessInput = input.trim().length >= 3 || description.trim().length >= 10 || files.length > 0;
  const hasReSourceData = reSourceDrafts.length > 0;
  const canSubmit = !!selectedIndustry && (hasBusinessInput || hasReSourceData);

  const handleFilesSelected = (selected: FileList | null) => {
    if (!selected) return;
    const newFiles = Array.from(selected).slice(0, MAX_FILES - files.length);
    setFiles((prev) => [...prev, ...newFiles].slice(0, MAX_FILES));
  };

  const removeFile = (index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const inputDetectedAsUrl = isUrl(input);

  const setStage = (stage: SetupStage, status: 'active' | 'done') => {
    setStages((prev) => ({ ...prev, [stage]: status }));
  };

  const toggleChannel = (ch: Channel) => {
    setSelectedChannels((prev) =>
      prev.includes(ch) ? prev.filter((c) => c !== ch) : [...prev, ch]
    );
  };

  // ── RE Source Extraction Handlers ───────────────────────────────────

  const hasDraftFromSource = (sourceType: string) =>
    reSourceDrafts.some((d) => d.sourceType === sourceType);

  const handleZillowExtract = async () => {
    if (!zillowUrl.trim()) return;
    setReSourceLoading('zillow_profile');
    setReSourceError(null);
    try {
      const draft = await zillowExtract.mutateAsync(zillowUrl.trim());
      setReSourceDrafts((prev) => [...prev.filter((d) => d.sourceType !== 'zillow_profile'), draft]);
    } catch (err) {
      setReSourceError(err instanceof Error ? err.message : 'Zillow extraction failed');
    } finally {
      setReSourceLoading(null);
    }
  };

  const handleLicenseLookup = async () => {
    if (!licenseState || !licenseNumber.trim()) return;
    setReSourceLoading('license_lookup');
    setReSourceError(null);
    try {
      const draft = await licenseLookupMutation.mutateAsync({
        state: licenseState,
        licenseNumber: licenseNumber.trim(),
      });
      setReSourceDrafts((prev) => [...prev.filter((d) => d.sourceType !== 'license_lookup'), draft]);
    } catch (err) {
      setReSourceError(err instanceof Error ? err.message : 'License lookup failed');
    } finally {
      setReSourceLoading(null);
    }
  };

  const handleCrmAnalyze = async () => {
    if (!crmFile) return;
    setReSourceLoading('crm_import');
    setReSourceError(null);
    try {
      const text = await crmFile.text();
      const draft = await crmAnalyzeMutation.mutateAsync(text);
      setReSourceDrafts((prev) => [...prev.filter((d) => d.sourceType !== 'crm_import'), draft]);
    } catch (err) {
      setReSourceError(err instanceof Error ? err.message : 'CRM analysis failed');
    } finally {
      setReSourceLoading(null);
    }
  };

  const clientSideMergeDrafts = (drafts: AgentProfileDraft[]): AgentProfileDraft => {
    if (drafts.length === 0) return { sourceType: 'manual' };
    if (drafts.length === 1) return { ...drafts[0] };

    const merged: AgentProfileDraft = { sourceType: 'manual' };
    const priority = ['manual', 'license_lookup', 'zillow_profile', 'website', 'crm_import', 'documents'];
    const sorted = [...drafts].sort((a, b) => {
      const ai = priority.indexOf(a.sourceType);
      const bi = priority.indexOf(b.sourceType);
      return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
    });

    const stringFields = [
      'agentName', 'brokerageName', 'teamName', 'bio',
      'primaryCity', 'primaryState', 'licenseNumber', 'licenseState',
      'licenseStatus', 'websiteUrl', 'zillowProfileUrl',
    ] as const;

    const arrayFields = [
      'specialties', 'serviceAreas', 'inferredAudience', 'inferredPriceBands', 'notes',
    ] as const;

    for (const field of stringFields) {
      for (const draft of sorted) {
        const val = draft[field];
        if (val && String(val).trim()) {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          (merged as any)[field] = val;
          break;
        }
      }
    }

    for (const field of arrayFields) {
      const all: string[] = [];
      for (const draft of sorted) {
        const arr = draft[field];
        if (Array.isArray(arr)) all.push(...arr);
      }
      if (all.length > 0) {
        const seen = new Set<string>();
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (merged as any)[field] = all.filter((v) => {
          const key = v.toLowerCase().trim();
          if (seen.has(key)) return false;
          seen.add(key);
          return true;
        });
      }
    }

    // Merge example listings
    const listings = sorted.flatMap((d) => d.exampleListings ?? []);
    if (listings.length > 0) merged.exampleListings = listings;

    // Merge social links
    const socialLinks: Record<string, string> = {};
    for (const draft of sorted) {
      if (draft.socialLinks) {
        for (const [k, v] of Object.entries(draft.socialLinks)) {
          if (v && !socialLinks[k]) socialLinks[k] = v;
        }
      }
    }
    if (Object.keys(socialLinks).length > 0) {
      merged.socialLinks = socialLinks as AgentProfileDraft['socialLinks'];
    }

    return merged;
  };

  const handleReConfirmAndContinue = () => {
    setShowConfirmation(false);
    // mergedDraft is already set, proceed with setup
    handleSetup();
  };

  const handleReProceedToConfirmation = () => {
    const draft = clientSideMergeDrafts(reSourceDrafts);
    setMergedDraft(draft);
    setShowConfirmation(true);
  };

  const handleSetup = async () => {
    if (setupRunning.current) return;
    setupRunning.current = true;
    setStep(1);
    setError(null);
    setGeneratedDrafts([]);
    setAnalyzeResult(null);
    setCrawlPages([]);
    setCrawlDone(false);
    setUploadedDocNames([]);
    setExtractedDataItems([]);
    setEarlyBrandData(null);

    const hasFiles = files.length > 0;
    setStages({
      uploading: hasFiles ? 'active' : 'skipped',
      analyzing: hasFiles ? 'pending' : 'active',
      extracting: 'pending',
      extractingData: 'pending',
      importing: 'pending',
      workspace: 'pending',
      generating: 'pending',
      postsGenerated: 0,
      dataItemsImported: 0,
    });

    try {
      // Stage 0.5: Upload documents (if any)
      let documentTexts: string[] = [];
      if (hasFiles) {
        const uploadResult = await uploadDocuments.mutateAsync(files);
        documentTexts = uploadResult.documents.map((d) => d.text);
        setUploadedDocNames(uploadResult.documents.map((d) => d.filename));
        setStage('uploading', 'done');
        setStage('analyzing', 'active');
      }

      // Append description as additional context if provided
      if (description.trim()) {
        documentTexts.push(description.trim());
      }

      // Stage 1: Stream analyze
      const inputType = inputDetectedAsUrl ? 'url' : 'text';
      const inputValue = inputType === 'url' ? normalizeUrl(input) : input.trim();

      const result = await consumeAnalyzeStream(
        {
          input: inputValue,
          inputType,
          documentTexts: documentTexts.length > 0 ? documentTexts : undefined,
          industryKey: selectedIndustry ?? undefined,
          agentProfileDraft: mergedDraft ?? undefined,
        },
        {
          onCrawlPage: (page) => {
            setCrawlPages((prev) => {
              if (prev.some((p) => p.url === page.url)) return prev;
              return [...prev, page];
            });
          },
          onCrawlDone: () => {
            setCrawlDone(true);
            setStage('analyzing', 'done');
            setStage('extracting', 'active');
          },
          onBrandDone: (brandData) => {
            setEarlyBrandData(brandData);
            setStage('extracting', 'done');
            setStage('extractingData', 'active');
          },
          onDataProgress: (items) => {
            setExtractedDataItems(items);
          },
          onDataDone: (items) => {
            setExtractedDataItems(items);
            setStage('extractingData', 'done');
          },
          onError: (message) => {
            setError(message);
          },
        }
      );

      if (!result) {
        if (!error) setError('Analysis did not complete. Please try again.');
        setupRunning.current = false;
        return;
      }

      setAnalyzeResult(result);

      // Populate interactive options from AI suggestions
      setSelectedTone(mapToneToOption(result.voiceData.tone));
      setSelectedGoal(result.suggestedGoal);
      setSelectedChannels(result.suggestedChannels);

      // Stage 3: Create workspace
      setStage('workspace', 'active');
      const brandName = result.brandData.name || input.trim().slice(0, 60);
      const slug = slugify(brandName);
      const client = await createClient.mutateAsync({
        name: brandName,
        slug,
        logoUrl: result.brandData.logoUrl || undefined,
        industryKey: selectedIndustry ?? undefined,
      });
      setCreatedClientId(client.id);

      // Save profiles using the AI-extracted data
      await saveProfiles(client.id, result);
      setStage('workspace', 'done');

      // Stage 3.5: Import data items
      if (result.dataItems && result.dataItems.length > 0) {
        setStage('importing', 'active');
        try {
          const importSourceType = inputType === 'url' ? 'URL' : 'TEXT';
          await apiFetch(`workspaces/${client.id}/data-import/confirm`, {
            method: 'POST',
            body: JSON.stringify({
              items: result.dataItems.map(({ type, title, summary, dataJson, tags, priority }) => ({
                type, title, summary, dataJson, tags, priority,
              })),
              sourceType: importSourceType,
              sourceUrl: inputType === 'url' ? normalizeUrl(input) : undefined,
            }),
          });
          setStages((prev) => ({ ...prev, importing: 'done', dataItemsImported: result!.dataItems.length }));
        } catch (importErr: unknown) {
          const msg = importErr instanceof Error ? importErr.message : String(importErr);
          console.error('[onboarding] Data import failed:', msg, '| items:', result!.dataItems.length);
          // Retry once — the first attempt may fail due to a race condition
          try {
            const importSourceType = inputType === 'url' ? 'URL' : 'TEXT';
            await apiFetch(`workspaces/${client.id}/data-import/confirm`, {
              method: 'POST',
              body: JSON.stringify({
                items: result!.dataItems.map(({ type, title, summary, dataJson, tags, priority }) => ({
                  type, title, summary, dataJson, tags, priority,
                })),
                sourceType: importSourceType,
                sourceUrl: inputType === 'url' ? normalizeUrl(input) : undefined,
              }),
            });
            setStages((prev) => ({ ...prev, importing: 'done', dataItemsImported: result!.dataItems.length }));
          } catch (retryErr) {
            console.error('[onboarding] Data import retry also failed:', retryErr instanceof Error ? retryErr.message : retryErr);
            setStages((prev) => ({ ...prev, importing: 'done', dataItemsImported: 0 }));
          }
        }
      } else {
        setStages((prev) => ({ ...prev, importing: 'skipped' }));
      }

      // Background: upload extracted external images to Cloudinary
      if (result.dataItems && result.dataItems.length > 0) {
        const imageUrls = new Set<string>();
        for (const item of result.dataItems) {
          const imgUrl = (item.dataJson as Record<string, unknown>)?.imageUrl;
          if (typeof imgUrl === 'string' && imgUrl.startsWith('http') && !imgUrl.includes('cloudinary')) {
            imageUrls.add(imgUrl);
          }
        }
        if (imageUrls.size > 0) {
          // Fire-and-forget — don't block user
          (async () => {
            try {
              // Create onboarding folder
              const folderName = `Onboarding — ${brandName}`;
              let folderId: string | undefined;
              try {
                const folderRes = await apiFetch<{ id: string }>(`workspaces/${client.id}/folders`, {
                  method: 'POST',
                  body: JSON.stringify({ name: folderName }),
                });
                folderId = folderRes.id;
              } catch {
                // folder may already exist
              }

              const urlMap = new Map<string, string>();
              for (const url of Array.from(imageUrls)) {
                try {
                  const asset = await apiFetch<{ id: string; url: string }>(
                    `workspaces/${client.id}/assets/upload-from-url`,
                    {
                      method: 'POST',
                      body: JSON.stringify({ url, folderId }),
                    }
                  );
                  if (asset.url) {
                    urlMap.set(url, asset.url);
                    // Auto-tag fire-and-forget
                    apiFetch(`workspaces/${client.id}/assets/${asset.id}/auto-tag`, {
                      method: 'POST',
                      body: JSON.stringify({}),
                    }).catch(() => {});
                  }
                } catch {
                  // Skip failed uploads
                }
              }

              // Update data items with Cloudinary URLs
              if (urlMap.size > 0) {
                try {
                  const itemsRes = await apiFetch<{ dataItems: Array<{ id: string; dataJson: Record<string, unknown> }> }>(
                    `workspaces/${client.id}/business-data?limit=50`,
                  );
                  for (const item of (itemsRes.dataItems ?? [])) {
                    const origUrl = item.dataJson?.imageUrl;
                    if (typeof origUrl === 'string' && urlMap.has(origUrl)) {
                      await apiFetch(`business-data/${item.id}`, {
                        method: 'PATCH',
                        body: JSON.stringify({
                          dataJson: { ...item.dataJson, imageUrl: urlMap.get(origUrl) },
                        }),
                      }).catch(() => {});
                    }
                  }
                } catch {
                  // Non-critical
                }
              }
            } catch {
              console.error('[onboarding] Background image upload failed');
            }
          })();
        }
      }

      // Generation deferred to Step 4 — setup is complete after workspace + import
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Setup failed. Please try again.');
      setupRunning.current = false;
    }
  };

  const saveProfiles = async (clientId: string, result: OnboardingAnalyzeResult) => {
    const checkedFetch = async (url: string, init: RequestInit) => {
      const res = await fetch(url, init);
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error((data as { message?: string }).message || `Request failed (${res.status})`);
      }
      return res;
    };

    // Brand profile (include location from agent profile draft if available)
    await checkedFetch(`/api/proxy/workspaces/${clientId}/brand`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        description: result.brandData.description,
        industry: result.brandData.industry,
        audience: result.brandData.audience,
        website: result.brandData.website || null,
        offers: result.brandData.offers,
        competitors: result.brandData.competitors,
        city: mergedDraft?.primaryCity || null,
        state: mergedDraft?.primaryState || null,
        marketArea: mergedDraft?.serviceAreas?.[0] || mergedDraft?.primaryCity || null,
        serviceAreas: mergedDraft?.serviceAreas || null,
      }),
    });

    // Voice profile
    await checkedFetch(`/api/proxy/workspaces/${clientId}/voice`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        tone: result.voiceData.tone,
        voiceRulesJson: {
          do: result.voiceData.doRules,
          dont: result.voiceData.dontRules,
        },
        bannedPhrases: [],
        contentBuckets: result.voiceData.contentBuckets,
      }),
    });

    // Media profile (default — enables image generation)
    await checkedFetch(`/api/proxy/workspaces/${clientId}/media`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode: 'BRAND_ASSETS_PLUS_AI' }),
    });

    // Channel settings
    const channels = result.suggestedChannels.length > 0
      ? result.suggestedChannels
      : ['INSTAGRAM' as Channel];
    await checkedFetch(`/api/proxy/workspaces/${clientId}/channels`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        items: channels.map((ch) => ({ channel: ch, isEnabled: true })),
      }),
    });
  };

  const handleFinish = (onboarded = false) => {
    if (createdClientId) {
      router.push(`/workspaces/${createdClientId}${onboarded ? '?onboarded=true' : ''}`);
    } else {
      router.push('/workspaces');
    }
  };

  const handleRegenerated = (oldIndex: number, newDraft: Draft) => {
    setGeneratedDrafts((prev) => prev.map((d, i) => (i === oldIndex ? newDraft : d)));
  };

  const handleBulkApproveAndSchedule = async () => {
    if (!createdClientId) return;

    // If no channel connected, just approve all (don't try to schedule)
    if (!hasConnectedChannel) {
      setBulkActionRunning(true);
      setBulkError(null);
      try {
        for (const draft of generatedDrafts) {
          if (draft.status !== 'APPROVED' && draft.status !== 'SCHEDULED') {
            await apiFetch(`drafts/${draft.id}/approve`, { method: 'POST' });
          }
        }
        setBulkSuccess(true);
        await delay(1500);
        handleFinish(true);
      } catch (err) {
        setBulkError(err instanceof Error ? err.message : 'Bulk action failed.');
        setBulkActionRunning(false);
      }
      return;
    }

    setBulkActionRunning(true);
    setBulkError(null);
    try {
      for (let i = 0; i < generatedDrafts.length; i++) {
        const draft = generatedDrafts[i];
        if (draft.status !== 'APPROVED' && draft.status !== 'SCHEDULED') {
          await apiFetch(`drafts/${draft.id}/approve`, { method: 'POST' });
        }
        if (draft.status !== 'SCHEDULED') {
          const time = getScheduleTime(i);
          await apiFetch(`drafts/${draft.id}/schedule`, {
            method: 'POST',
            body: JSON.stringify({ scheduledFor: time.iso }),
          });
        }
      }
      setBulkSuccess(true);
      await delay(1500);
      handleFinish(true);
    } catch (err) {
      setBulkError(err instanceof Error ? err.message : 'Bulk action failed.');
      setBulkActionRunning(false);
    }
  };

  const handleBulkApproveOnly = async () => {
    if (!createdClientId) return;
    setBulkActionRunning(true);
    setBulkError(null);
    try {
      for (const draft of generatedDrafts) {
        if (draft.status !== 'APPROVED' && draft.status !== 'SCHEDULED') {
          await apiFetch(`drafts/${draft.id}/approve`, { method: 'POST' });
        }
      }
      setBulkSuccess(true);
      await delay(1500);
      handleFinish(true);
    } catch (err) {
      setBulkError(err instanceof Error ? err.message : 'Bulk action failed.');
      setBulkActionRunning(false);
    }
  };

  const handleGenerateMore = async () => {
    if (!createdClientId || !analyzeResult || generatingMore) return;
    setGeneratingMore(true);
    try {
      const channels = analyzeResult.suggestedChannels.length > 0
        ? analyzeResult.suggestedChannels
        : ['INSTAGRAM' as Channel];
      const brandName = analyzeResult.brandData.name || 'Your Brand';
      const defaultGuidance = `Create a specific, ready-to-publish social media post for ${brandName}. Use concrete details — real numbers, specific benefits, and direct language. Reference their ${analyzeResult.brandData.industry || 'business'} expertise. No vague or generic statements.`;
      const coreTemplates = analyzeResult.coreTemplates ?? [];
      const angles = analyzeResult.starterAngles ?? [];
      const bd = analyzeResult.brandData;
      const bizContext = [
        bd.name && `Business: ${bd.name}.`,
        bd.offers && `Offerings: ${bd.offers}.`,
        bd.audience && `Audience: ${bd.audience}.`,
      ].filter(Boolean).join(' ');
      const idx = generatedDrafts.length;
      const template = coreTemplates[idx % coreTemplates.length] ?? undefined;
      const channel = channels[idx % channels.length];
      const ids = importedDataItemIds.current;
      const dataItemId = ids[idx];
      const baseGuidance = template?.guidance || angles[idx % angles.length] || defaultGuidance;
      const guidance = bizContext ? `${baseGuidance} ${bizContext}` : baseGuidance;
      const draft = await generate.mutateAsync({
        clientId: createdClientId,
        kind: 'POST',
        channel,
        guidance,
        ...(template ? { templateType: template.type } : {}),
        ...(dataItemId ? { dataItemId } : {}),
      });
      setGeneratedDrafts((prev) => [...prev, draft]);
      setTemplateLabels((prev) => [...prev, template?.title || '']);
      // Fire-and-forget image generation — skip if draft already has an image from business data
      if (draft.imageGuidance && !draft.mediaUrl) {
        apiFetch('assets/generate', {
          method: 'POST',
          body: JSON.stringify({
            clientId: createdClientId,
            guidance: draft.imageGuidance,
            draftId: draft.id,
            channel,
          }),
        }).catch(() => {});
      }
    } catch {
      // Don't block the experience
    } finally {
      setGeneratingMore(false);
    }
  };

  const allDone = (stages.uploading === 'done' || stages.uploading === 'skipped') &&
    stages.analyzing === 'done' &&
    stages.extracting === 'done' &&
    (stages.extractingData === 'done' || stages.extractingData === 'skipped') &&
    (stages.importing === 'done' || stages.importing === 'skipped') &&
    stages.workspace === 'done';

  // ── Step 4 auto-generation: runs planner then generates posts ────

  const generationRunning = useRef(false);

  useEffect(() => {
    if (step !== 4 || !createdClientId || !analyzeResult || generatedDrafts.length > 0 || generationRunning.current) return;
    generationRunning.current = true;
    setStage('generating', 'active');

    (async () => {
      try {
        const bd = analyzeResult.brandData;
        const brandName = bd.name || 'Your Brand';
        const bizContext = [
          bd.name && `Business: ${bd.name}.`,
          bd.offers && `Offerings: ${bd.offers}.`,
          bd.audience && `Audience: ${bd.audience}.`,
          bd.description && `About: ${bd.description}.`,
        ].filter(Boolean).join(' ');

        // Fetch latest data items
        let dataItems: { id: string; dataJson: Record<string, unknown> }[] = [];
        try {
          const itemsRes = await apiFetch<{ dataItems: { id: string; dataJson: Record<string, unknown> }[] }>(
            `workspaces/${createdClientId}/business-data?limit=10`,
          );
          dataItems = itemsRes.dataItems ?? [];
          importedDataItemIds.current = dataItems.map((item) => item.id);
        } catch {
          // No data items — planner will use fallback templates
        }

        // Run planner
        const slots = buildOnboardingGenerationPlan({
          coreTemplates: (analyzeResult.coreTemplates ?? []) as { type: string; title: string; guidance: string; conditions?: { hasData?: boolean; requiredDataType?: string } }[],
          starterAngles: analyzeResult.starterAngles ?? [],
          dataItems,
          connectedChannels: connectedChannelsList,
          industryKey: selectedIndustry ?? '',
          brandContext: bizContext,
        });

        // Generate each slot (exclude YouTube — requires video, too expensive for onboarding)
        const nonVideoChannels = connectedChannelsList.filter((ch) => ch !== 'YOUTUBE');
        const fallbackChannel = nonVideoChannels[0] ?? analyzeResult.suggestedChannels.find((ch) => ch !== 'YOUTUBE') ?? ('INSTAGRAM' as Channel);
        for (const slot of slots) {
          const channel = slot.channel ?? fallbackChannel;
          try {
            const draft = await generate.mutateAsync({
              clientId: createdClientId,
              kind: 'POST',
              channel,
              guidance: slot.guidance,
              ...(slot.templateType ? { templateType: slot.templateType } : {}),
              ...(slot.dataItemId ? { dataItemId: slot.dataItemId } : {}),
            });
            setGeneratedDrafts((prev) => [...prev, draft]);
            setTemplateLabels((prev) => [...prev, slot.title]);
            setStages((prev) => ({ ...prev, postsGenerated: prev.postsGenerated + 1 }));

            // Fire-and-forget image generation
            if (draft.imageGuidance) {
              apiFetch('assets/generate', {
                method: 'POST',
                body: JSON.stringify({
                  clientId: createdClientId,
                  guidance: draft.imageGuidance,
                  draftId: draft.id,
                  channel,
                }),
              }).catch(() => {});
            }
          } catch {
            // Continue generating remaining posts if one fails
          }
        }
        setStage('generating', 'done');
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Generation failed.');
      } finally {
        generationRunning.current = false;
      }
    })();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step, createdClientId]);

  // ── Step 1: Business Input ──────────────────────────────────────────

  if (step === 0) {
    const previewContent = INDUSTRY_PREVIEW_CONTENT[selectedIndustry ?? ''] ?? DEFAULT_PREVIEW_CONTENT;

    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-8">
        <div className="text-center space-y-2">
          <Image src="/icon-192.png" alt="Squadpitch" width={48} height={48} className="mx-auto mb-2" />
          <h1 className="text-3xl font-bold text-white">
            Let&apos;s build your marketing system
          </h1>
          <p className="text-sm text-white-50 max-w-md mx-auto">
            Choose your industry and add your business details — we&apos;ll generate tailored content in seconds.
          </p>
          <p className="text-sm font-medium text-accent-green-110/80">
            You&apos;ll get posts, ideas, and a full content plan instantly.
          </p>
        </div>

        <div className="w-full max-w-xl space-y-6">
          {/* ── Step 1: Industry Selection (primary) ── */}
          <div className="space-y-3">
            <p className="text-sm font-semibold text-white">
              Choose your industry
            </p>
            {industries.length > 0 && (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {industries.map((profile) => {
                  const IconComponent = INDUSTRY_ICON_MAP[profile.ui.icon] ?? Briefcase;
                  const isSelected = selectedIndustry === profile.key;
                  return (
                    <button
                      key={profile.key}
                      type="button"
                      onClick={() => setSelectedIndustry(isSelected ? null : profile.key)}
                      className={cn(
                        'flex items-center gap-2.5 px-3.5 py-3 rounded-xl border transition-all text-[13px] font-medium text-left h-[52px]',
                        isSelected
                          ? 'border-accent-green-110 bg-accent-green-110/15 text-accent-green-110 ring-1 ring-accent-green-110'
                          : 'border-white-10 bg-white-5 text-white-60 hover:border-white-20 hover:text-white-80',
                      )}
                    >
                      <IconComponent className="w-4 h-4 flex-shrink-0" />
                      <span className="leading-snug">{profile.label}</span>
                    </button>
                  );
                })}
              </div>
            )}

            {/* Selection feedback */}
            {selectedIndustry && activeProfile && (
              <p className="text-sm text-accent-green-110 text-center animate-in fade-in duration-200">
                Great — we&apos;ll tailor content for {activeProfile.label}
              </p>
            )}
          </div>

          {/* ── RE Agent Profile Sources ── */}
          {isRealEstate && !showConfirmation && (
            <div className="space-y-3">
              <div>
                <p className="text-sm font-semibold text-white">
                  Set up your agent profile
                </p>
                <p className="text-xs text-white-40 mt-0.5">
                  Add sources to auto-fill your profile — the more you add, the better your content.
                </p>
              </div>

              {/* Zillow */}
              <RealEstateSourceCard
                icon={Home}
                label="Zillow Agent Profile"
                description="We'll extract your bio, specialties, service areas, and listings."
                done={hasDraftFromSource('zillow_profile')}
                loading={reSourceLoading === 'zillow_profile'}
                error={reSourceLoading === 'zillow_profile' ? null : reSourceError}
              >
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={zillowUrl}
                    onChange={(e) => setZillowUrl(e.target.value)}
                    placeholder="https://www.zillow.com/profile/your-name"
                    className="flex-1 px-3 py-2 rounded-lg bg-sp-card border border-white-15 text-white text-sm focus:outline-none focus:border-accent-green-110 placeholder:text-white-30"
                  />
                  <button
                    type="button"
                    onClick={handleZillowExtract}
                    disabled={!zillowUrl.trim() || reSourceLoading === 'zillow_profile'}
                    className="px-4 py-2 rounded-lg bg-accent-green-110 text-sp-surface text-sm font-semibold hover:bg-accent-green-120 transition-colors disabled:opacity-40"
                  >
                    Extract
                  </button>
                </div>
              </RealEstateSourceCard>

              {/* License Lookup */}
              <RealEstateSourceCard
                icon={Shield}
                label="License Number Lookup"
                description="Enter your state and license number for verification."
                done={hasDraftFromSource('license_lookup')}
                loading={reSourceLoading === 'license_lookup'}
                error={reSourceLoading === 'license_lookup' ? null : reSourceError}
              >
                <div className="flex gap-2">
                  <select
                    value={licenseState}
                    onChange={(e) => setLicenseState(e.target.value)}
                    className="px-3 py-2 rounded-lg bg-sp-card border border-white-15 text-white text-sm focus:outline-none focus:border-accent-green-110"
                  >
                    <option value="">State</option>
                    {['AL','AK','AZ','AR','CA','CO','CT','DE','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY'].map((st) => (
                      <option key={st} value={st}>{st}</option>
                    ))}
                  </select>
                  <input
                    type="text"
                    value={licenseNumber}
                    onChange={(e) => setLicenseNumber(e.target.value)}
                    placeholder="License number"
                    className="flex-1 px-3 py-2 rounded-lg bg-sp-card border border-white-15 text-white text-sm focus:outline-none focus:border-accent-green-110 placeholder:text-white-30"
                  />
                  <button
                    type="button"
                    onClick={handleLicenseLookup}
                    disabled={!licenseState || !licenseNumber.trim() || reSourceLoading === 'license_lookup'}
                    className="px-4 py-2 rounded-lg bg-accent-green-110 text-sp-surface text-sm font-semibold hover:bg-accent-green-120 transition-colors disabled:opacity-40"
                  >
                    Look Up
                  </button>
                </div>
              </RealEstateSourceCard>

              {/* CRM Import */}
              <RealEstateSourceCard
                icon={Database}
                label="CRM Import (CSV)"
                description="Upload a CSV export from your CRM to infer service areas and client types."
                done={hasDraftFromSource('crm_import')}
                loading={reSourceLoading === 'crm_import'}
                error={reSourceLoading === 'crm_import' ? null : reSourceError}
              >
                <div className="flex gap-2 items-center">
                  <input
                    type="file"
                    accept=".csv"
                    onChange={(e) => setCrmFile(e.target.files?.[0] ?? null)}
                    className="flex-1 text-sm text-white-50 file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-white-10 file:text-white-70 hover:file:bg-white-15"
                  />
                  <button
                    type="button"
                    onClick={handleCrmAnalyze}
                    disabled={!crmFile || reSourceLoading === 'crm_import'}
                    className="px-4 py-2 rounded-lg bg-accent-green-110 text-sp-surface text-sm font-semibold hover:bg-accent-green-120 transition-colors disabled:opacity-40"
                  >
                    Analyze
                  </button>
                </div>
              </RealEstateSourceCard>

              {/* MLS Integration — Coming Soon */}
              <RealEstateSourceCard
                icon={Building2}
                label="MLS Integration"
                comingSoon
              >
                <div />
              </RealEstateSourceCard>

              {/* Review & Confirm button */}
              {reSourceDrafts.length > 0 && (
                <button
                  type="button"
                  onClick={handleReProceedToConfirmation}
                  className="w-full px-4 py-2.5 rounded-xl border border-accent-green-110/40 text-accent-green-110 text-sm font-semibold hover:bg-accent-green-110/10 transition-colors"
                >
                  Review Extracted Profile ({reSourceDrafts.length} source{reSourceDrafts.length > 1 ? 's' : ''})
                </button>
              )}
            </div>
          )}

          {/* ── RE Confirmation Step ── */}
          {isRealEstate && showConfirmation && mergedDraft && (
            <AgentProfileConfirmation
              draft={mergedDraft}
              onChange={setMergedDraft}
              onConfirm={handleReConfirmAndContinue}
              onBack={() => setShowConfirmation(false)}
            />
          )}

          {/* ── Step 2: Business Details ── */}
          {(!isRealEstate || !showConfirmation) && (
          <div className="space-y-4">
            <div>
              <p className="text-sm font-semibold text-white">
                Add your business details
              </p>
              <p className="text-xs text-white-40 mt-0.5">
                Optional, but improves results. We can generate content even if you skip this.
              </p>
            </div>

            {/* Website URL */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-white-60 flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5" />
                Website URL
              </label>
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && canSubmit) handleSetup();
                }}
                placeholder={activeProfile?.onboarding.websitePlaceholder ?? 'yourwebsite.com'}
                className="w-full px-4 py-3.5 rounded-xl bg-sp-card border border-white-15 text-white text-sm focus:outline-none focus:border-accent-green-110 focus:ring-1 focus:ring-accent-green-110/30 placeholder:text-white-30"
              />
              <p className="text-xs text-white-40">
                No website? No problem — describe your business below.
              </p>
            </div>

            {/* Business description */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-white-60 flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5" />
                {activeProfile?.onboarding.extraContextLabel ?? 'Business description'}
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder={activeProfile?.onboarding.extraContextPlaceholder ?? 'What does your business do? Who do you serve?'}
                rows={3}
                className="w-full px-4 py-3 rounded-xl bg-sp-card border border-white-15 text-white text-sm focus:outline-none focus:border-accent-green-110 focus:ring-1 focus:ring-accent-green-110/30 placeholder:text-white-30 resize-none"
              />
            </div>

            {/* Document upload — collapsed to reduce clutter */}
            <details className="group/upload">
              <summary className="text-xs text-white-40 cursor-pointer hover:text-white-60 transition-colors select-none flex items-center gap-1.5 list-none [&::-webkit-details-marker]:hidden">
                <ChevronRight className="w-3 h-3 transition-transform group-open/upload:rotate-90" />
                <Upload className="w-3 h-3" />
                Upload documents instead (PDF, DOCX, TXT, CSV)
              </summary>
              <div className="mt-2">
                <div
                  onClick={() => fileInputRef.current?.click()}
                  onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); }}
                  onDrop={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    handleFilesSelected(e.dataTransfer.files);
                  }}
                  className="w-full px-4 py-3 rounded-xl border border-dashed border-white-15 hover:border-accent-green-110/40 transition-colors cursor-pointer flex items-center gap-3"
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    accept={ACCEPTED_FILE_TYPES}
                    className="hidden"
                    onChange={(e) => {
                      handleFilesSelected(e.target.files);
                      e.target.value = '';
                    }}
                  />
                  <FileText className="w-4 h-4 text-white-40 flex-shrink-0" />
                  <p className="text-xs text-white-50">
                    Brochures, menus, listings, service sheets, brand docs
                  </p>
                </div>
                {files.length > 0 && (
                  <div className="flex flex-wrap gap-2 pt-2">
                    {files.map((f, i) => (
                      <div
                        key={`${f.name}-${i}`}
                        className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-sp-card border border-white-15 text-sm"
                      >
                        <FileText className="w-3.5 h-3.5 text-white-40 flex-shrink-0" />
                        <span className="text-white-80 truncate max-w-[160px]">{f.name}</span>
                        <span className="text-white-30 text-xs">
                          {(f.size / 1024).toFixed(0)}KB
                        </span>
                        <button
                          onClick={(e) => { e.stopPropagation(); removeFile(i); }}
                          className="text-white-30 hover:text-white-80 transition-colors"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </details>
          </div>
          )}

          {/* ── Primary CTA ── */}
          {selectedIndustry && (
            <p className="text-xs text-white-40 text-center">Takes about 60 seconds</p>
          )}
          {(!isRealEstate || !showConfirmation) && (
          <button
            onClick={isRealEstate && reSourceDrafts.length > 0 && !mergedDraft ? handleReProceedToConfirmation : handleSetup}
            disabled={!canSubmit}
            className="w-full px-6 py-4 rounded-2xl bg-accent-green-110 text-sp-surface font-bold text-base flex items-center justify-center gap-2 hover:bg-accent-green-120 transition-colors disabled:opacity-40 disabled:cursor-not-allowed shadow-glow-green"
          >
            <Sparkles className="w-5 h-5" />
            {activeProfile ? `Generate My ${activeProfile.label} Marketing System` : 'Choose an industry to continue'}
          </button>
          )}

          <div className="flex items-center justify-center gap-4 text-[11px] text-white-30">
            <span>AI-powered</span>
            <span className="w-1 h-1 rounded-full bg-white-15" />
            <span>No credit card needed</span>
          </div>
        </div>

        {/* ── Preview section — weekly content plan ── */}
        <div className="w-full max-w-xl space-y-3 pt-2">
          <p className="text-sm font-semibold text-white-60 text-center">
            We&apos;ll create your weekly content plan
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {previewContent.map((item, i) => (
              <div
                key={i}
                className={cn(
                  'rounded-xl bg-sp-card border border-white-10 p-4 space-y-2.5 transition-all duration-300',
                  selectedIndustry ? 'opacity-60' : 'opacity-30',
                )}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-semibold text-accent-green-110 uppercase tracking-wide">
                    {item.channel}
                  </span>
                  <span className="text-[10px] font-medium text-white-30">
                    {PREVIEW_DAYS[i]}
                  </span>
                </div>
                <p className="text-xs font-semibold text-white-80 leading-snug">{item.title}</p>
                <p className="text-[11px] text-white-40 leading-relaxed line-clamp-3">{item.snippet}</p>
                <div className="flex gap-1.5 pt-1">
                  <div className="h-5 w-14 bg-accent-green-110/10 rounded-full" />
                  <div className="h-5 w-10 bg-white-5 rounded-full" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ── Step 2: Channel Connection ──────────────────────────────────────

  if (step === 2) {
    const channelRecs = analyzeResult
      ? (() => {
          const industryProfile = industries.find((p) => p.key === selectedIndustry);
          return industryProfile?.content.channelRecommendations ?? null;
        })()
      : null;

    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] py-8">
        <OnboardingChannelConnect
          clientId={createdClientId!}
          industryKey={selectedIndustry ?? ''}
          channelRecommendations={channelRecs}
          onContinue={(channels) => {
            setConnectedChannelsList(channels);
            setStep(3);
          }}
        />
      </div>
    );
  }

  // ── Step 3: Tech Stack / Data Sources ─────────────────────────────

  if (step === 3) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] py-8">
        <OnboardingTechStack
          clientId={createdClientId!}
          onContinue={() => setStep(4)}
        />
      </div>
    );
  }

  // ── Step 4: Generate & Review ─────────────────────────────────────

  if (step === 4) {
    return (
      <div className="flex flex-col items-center min-h-[60vh] max-w-5xl mx-auto">
        {/* Success overlay */}
        {bulkSuccess && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-sp-surface/90 backdrop-blur-sm">
            <div className="flex flex-col items-center gap-4 animate-in fade-in zoom-in duration-300">
              <CheckCircle2 className="w-16 h-16 text-accent-green-110" />
              <p className="text-2xl font-bold text-white">
                {analyzeResult?.brandData.name
                  ? `${analyzeResult.brandData.name} is all set!`
                  : 'You\u2019re all set!'}
              </p>
              <p className="text-sm text-white-60">Taking you to your workspace...</p>
            </div>
          </div>
        )}

        {/* ── Level 1: Wow moment headline ── */}
        <div className="text-center space-y-3 pt-4 pb-2">
          <Image src="/icon-192.png" alt="Squadpitch" width={40} height={40} className="mx-auto" />
          {stages.generating === 'done' ? (
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-accent-green-110/15 text-accent-green-110 text-sm font-semibold animate-in fade-in duration-500">
              <CheckCircle2 className="w-4 h-4" />
              {analyzeResult?.brandData.name
                ? `Created for ${analyzeResult.brandData.name}`
                : 'Created for your business'}
            </div>
          ) : (
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white-10 text-white-60 text-sm font-medium animate-pulse">
              <Loader2 className="w-4 h-4 animate-spin" />
              Generating your content...
            </div>
          )}
          <h2 className="text-3xl sm:text-4xl font-bold text-white">
            {stages.generating === 'done' ? 'Your marketing system is ready' : 'Creating your content'}
          </h2>
          <p className="text-base text-white-60 max-w-lg mx-auto">
            {stages.generating !== 'done'
              ? `Writing ${stages.postsGenerated > 0 ? `${stages.postsGenerated} of 3` : ''} personalized posts based on your business data...`
              : analyzeResult?.brandData.name
                ? `Based on ${analyzeResult.brandData.name}'s profile${analyzeResult.brandData.industry ? ` and ${analyzeResult.brandData.industry.toLowerCase()} expertise` : ''}, here are posts you can publish today.`
                : 'Based on your business details, here are posts you can publish today.'}
          </p>
        </div>

        {/* No channels info banner */}
        {connectedChannelsList.length === 0 && stages.generating === 'done' && generatedDrafts.length > 0 && (
          <div className="w-full px-4 py-3 rounded-xl bg-white-5 border border-white-10 text-center text-sm text-white-50">
            These posts were created as content ideas. Connect a channel to publish them.
          </div>
        )}

        {/* ── Channel filter tabs ── */}
        {generatedDrafts.length > 0 && (() => {
          const draftChannels = Array.from(new Set(generatedDrafts.map((d) => d.channel)));
          return draftChannels.length > 1 ? (
            <div className="flex items-center gap-2 pt-4">
              <button
                onClick={() => setChannelFilter(null)}
                className={cn(
                  'px-4 py-2 rounded-full text-xs font-medium transition-all',
                  !channelFilter
                    ? 'bg-accent-green-110/15 text-accent-green-110 ring-1 ring-accent-green-110'
                    : 'bg-white-5 text-white-50 hover:bg-white-10',
                )}
              >
                All
              </button>
              {draftChannels.map((ch) => (
                <button
                  key={ch}
                  onClick={() => setChannelFilter(ch === channelFilter ? null : ch)}
                  className={cn(
                    'px-4 py-2 rounded-full text-xs font-medium transition-all',
                    channelFilter === ch
                      ? 'bg-accent-green-110/15 text-accent-green-110 ring-1 ring-accent-green-110'
                      : 'bg-white-5 text-white-50 hover:bg-white-10',
                  )}
                >
                  {(ch === 'X' ? 'X' : ch.charAt(0) + ch.slice(1).toLowerCase()) + ' Preview'}
                </button>
              ))}
            </div>
          ) : null;
        })()}

        {/* ── Preview microcopy ── */}
        {generatedDrafts.length > 0 && (
          <p className="text-xs text-white-40 pt-2">
            Preview your content in different platform styles. Connect publishing channels anytime before scheduling.
          </p>
        )}

        {/* ── Weekly content plan ── */}
        {generatedDrafts.length > 0 && (() => {
          const SCHEDULE_DAYS = ['Monday', 'Wednesday', 'Friday', 'Tuesday', 'Thursday'];
          const channelLabel = (ch: string) => ch === 'X' ? 'X' : ch.charAt(0) + ch.slice(1).toLowerCase();
          return (
            <div className="w-full pt-6 pb-2 animate-in fade-in duration-500">
              <p className="text-sm font-semibold text-white-70 mb-3">Your weekly content plan</p>
              <div className="flex gap-3 overflow-x-auto pb-1">
                {generatedDrafts.slice(0, 5).map((d, i) => (
                  <div key={d.id} className="flex items-center gap-2.5 px-4 py-2.5 rounded-xl bg-white-5 border border-white-10 flex-shrink-0">
                    <span className="text-xs font-semibold text-accent-green-110">{SCHEDULE_DAYS[i % SCHEDULE_DAYS.length]}</span>
                    <span className="text-white-20">·</span>
                    <span className="text-xs text-white-60">{channelLabel(d.channel)} post</span>
                  </div>
                ))}
              </div>
            </div>
          );
        })()}

        {/* ── Level 2: Post cards + skeleton placeholders (single grid) ── */}
        {(() => {
          const shortenTitle = (t: string) =>
            t.replace(/^(Post|Share|Promote|Announce|Feature|Showcase|List|Create|Highlight)\s+(a |an |the |Your |Today's )?/i, '')
             .replace(/\s+Post$/i, '')
             .trim();
          const filteredDrafts = channelFilter
            ? generatedDrafts.filter((d) => d.channel === channelFilter)
            : generatedDrafts;
          const remainingSkeletons = stages.generating !== 'done'
            ? Math.max(0, 3 - generatedDrafts.length)
            : 0;

          if (filteredDrafts.length === 0 && remainingSkeletons === 0 && stages.generating === 'done') {
            return (
              <div className="p-8 rounded-2xl bg-sp-card border border-white-15 text-center w-full mt-6 space-y-3">
                <p className="text-base font-semibold text-white">
                  We created starter content — customize anytime
                </p>
                <p className="text-sm text-white-60">
                  Head to your dashboard to create and schedule posts.
                </p>
              </div>
            );
          }

          return (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 w-full pt-4 pb-2">
              {filteredDrafts.map((draft, i) => {
                const originalIndex = generatedDrafts.indexOf(draft);
                const label = templateLabels[originalIndex];
                return (
                  <div
                    key={draft.id}
                    className="animate-in fade-in slide-in-from-bottom-3 duration-300"
                    style={{ animationDelay: `${i * 120}ms`, animationFillMode: 'backwards' }}
                  >
                    <OnboardingPostCard
                      draft={draft}
                      clientId={createdClientId!}
                      brandName={analyzeResult?.brandData.name}
                      logoUrl={analyzeResult?.brandData.logoUrl}
                      defaultScheduleTime={getScheduleTime(originalIndex)}
                      onRegenerated={(newDraft) => handleRegenerated(originalIndex, newDraft)}
                      contentType={label ? shortenTitle(label) : undefined}
                      isFirstPost={originalIndex === 0}
                      industryKey={selectedIndustry ?? undefined}
                      postIndex={originalIndex}
                      channelConnected={hasConnectedChannel}
                    />
                  </div>
                );
              })}
              {Array.from({ length: remainingSkeletons }).map((_, i) => (
                <div key={`skeleton-${i}`} className="rounded-2xl border border-white-15 overflow-hidden bg-sp-card animate-pulse">
                  <div className="flex items-center gap-3 px-4 py-3">
                    <div className="w-8 h-8 rounded-full bg-white-10" />
                    <div className="flex-1 space-y-1.5">
                      <div className="h-3.5 w-28 bg-white-10 rounded" />
                      <div className="h-2.5 w-16 bg-white-10/60 rounded" />
                    </div>
                  </div>
                  <div className="px-4 py-3 space-y-2.5 border-t border-white-15">
                    <div className="h-3 w-full bg-white-10 rounded" />
                    <div className="h-3 w-5/6 bg-white-10 rounded" />
                    <div className="h-3 w-2/3 bg-white-10 rounded" />
                  </div>
                </div>
              ))}
            </div>
          );
        })()}

        {/* Generate More Content — lazy load additional posts */}
        {stages.generating === 'done' && generatedDrafts.length > 0 && generatedDrafts.length < 10 && (
          <button
            onClick={handleGenerateMore}
            disabled={generatingMore}
            className="mt-4 px-6 py-3 rounded-xl bg-white-5 border border-white-10 text-sm text-white-60 hover:bg-white-10 hover:text-white transition-colors flex items-center gap-2 disabled:opacity-50"
          >
            {generatingMore ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Sparkles className="w-4 h-4" />
            )}
            Generate More Content
          </button>
        )}

        {/* ── Level 3: Primary CTA area ── */}
        {generatedDrafts.length > 0 && (
          <div className="w-full space-y-4 pt-6">
            <button
              onClick={handleBulkApproveAndSchedule}
              disabled={bulkActionRunning}
              className="w-full py-5 rounded-2xl bg-accent-green-110 text-sp-surface font-bold text-lg flex items-center justify-center gap-2.5 hover:bg-accent-green-120 transition-colors disabled:opacity-50 shadow-glow-green"
            >
              {bulkActionRunning ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <ArrowRight className="w-5 h-5" />
              )}
              Approve &amp; Continue to Dashboard
            </button>

            <p className="text-center text-xs text-white-40">
              This is the start of your content system. Keep generating, approving, and publishing from your dashboard.
            </p>

            <div className="flex items-center justify-center gap-4">
              <button
                onClick={() => setStep(0)}
                className="text-xs text-white-30 hover:text-white-50 transition-colors"
              >
                Edit business info
              </button>
            </div>
          </div>
        )}

        {bulkError && <div className="w-full pt-2"><StatusBanner error={bulkError} /></div>}

        {/* ── Level 4: Brand context (de-emphasized) ── */}
        {analyzeResult && (
          <div className="w-full pt-6 border-t border-white-15 mt-6">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-accent-green-110/15 flex items-center justify-center text-xs font-bold text-accent-green-110 flex-shrink-0 overflow-hidden">
                {analyzeResult.brandData.logoUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={analyzeResult.brandData.logoUrl} alt={analyzeResult.brandData.name} className="w-full h-full object-cover" />
                ) : (
                  analyzeResult.brandData.name?.[0]?.toUpperCase() || '?'
                )}
              </div>
              <p className="text-sm text-white-70 flex-1 min-w-0 truncate">
                Built from <span className="text-white font-medium">{analyzeResult.brandData.name}</span>
                {analyzeResult.brandData.industry && <span> · {analyzeResult.brandData.industry}</span>}
                {analyzeResult.voiceData.tone && <span> · {analyzeResult.voiceData.tone} voice</span>}
              </p>
            </div>
          </div>
        )}

        {/* If no drafts, just show a continue button */}
        {generatedDrafts.length === 0 && (
          <button
            onClick={() => handleFinish()}
            className="px-8 py-3 rounded-2xl bg-accent-green-110 text-sp-surface font-semibold text-sm flex items-center gap-2 hover:bg-accent-green-120 transition-colors mt-4"
          >
            Go to Dashboard
            <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>
    );
  }

  // ── Step 2: AI Setup Screen (split layout) ──────────────────────────

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 min-h-[60vh]">
      {/* Left panel — Progress + Options */}
      <div className="space-y-6">
        <div>
          <Image src="/icon-192.png" alt="Squadpitch" width={36} height={36} className="mb-3" />
          <h2 className="text-2xl font-bold text-white-100">
            {(analyzeResult?.brandData ?? earlyBrandData)
              ? `Building ${(analyzeResult?.brandData ?? earlyBrandData)!.name}\u2019s content system`
              : 'Building your content system'}
          </h2>
          <p className="text-sm text-white-60 mt-1">
            {allDone
              ? 'Everything\u2019s ready \u2014 let\u2019s connect your channels'
              : (analyzeResult?.brandData ?? earlyBrandData)
                ? 'Setting up your workspace...'
                : 'Analyzing your business \u2014 this takes about a minute'}
          </p>
        </div>

        {/* Stage checklist */}
        <div className="space-y-3">
          {stages.uploading !== 'skipped' && (
            <StageRow
              status={stages.uploading}
              activeLabel="Reading your documents..."
              doneLabel="Documents understood"
            />
          )}
          <StageRow
            status={stages.analyzing}
            activeLabel={inputDetectedAsUrl ? industrySteps.explore : 'Learning about your business...'}
            doneLabel={
              inputDetectedAsUrl
                ? `${crawlPages.length} page${crawlPages.length !== 1 ? 's' : ''} explored`
                : 'Business analyzed'
            }
            activeHint={inputDetectedAsUrl ? `Reading pages from your site` : undefined}
          />
          <StageRow
            status={stages.extracting}
            activeLabel={industrySteps.understand}
            doneLabel="Brand captured"
            activeHint="AI is analyzing your voice, audience, and positioning"
          />
          {stages.extractingData !== 'skipped' && (() => {
            const dataStatus =
              (stages.importing === 'done' || stages.importing === 'skipped')
                ? 'done'
                : stages.extractingData === 'done' && stages.importing === 'active'
                  ? 'active'
                  : stages.extractingData;
            const importedCount = stages.dataItemsImported ?? extractedDataItems.length;
            return (
              <StageRow
                status={dataStatus}
                activeLabel={industrySteps.insights}
                doneLabel={
                  importedCount > 0
                    ? `${importedCount} ${importedCount !== 1 ? bdLabels.itemPlural.toLowerCase() : bdLabels.itemSingular.toLowerCase()} imported`
                    : `${bdLabels.itemPlural} extracted`
                }
                activeHint={
                  extractedDataItems.length > 0
                    ? `${extractedDataItems.length} found so far — still searching...`
                    : `Finding testimonials, ${bdLabels.itemPlural.toLowerCase()}, and key data`
                }
              />
            );
          })()}
          <StageRow
            status={stages.workspace}
            activeLabel={industrySteps.prepare}
            doneLabel="Workspace created"
          />
        </div>

        {error && (
          <StatusBanner error={error} />
        )}

        {/* Interactive options — collapsible, de-emphasized */}
        {analyzeResult && (
          <details className="pt-2 group/customize">
            <summary className="text-xs text-white-60 cursor-pointer hover:text-white-70 transition-colors select-none flex items-center gap-1.5 list-none [&::-webkit-details-marker]:hidden">
              <ChevronRight className="w-3 h-3 text-white-40 transition-transform group-open/customize:rotate-90" />
              <SlidersHorizontal className="w-3 h-3 text-accent-green-110" />
              Customize tone, goal & channels
            </summary>
            <div className="space-y-3 mt-3">
              {/* Tone selector — inline */}
              <div className="flex items-center gap-3">
                <span className="text-xs font-medium text-white-60 w-16 flex-shrink-0">Tone</span>
                <div className="flex gap-1.5">
                  {TONE_OPTIONS.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setSelectedTone(t.id)}
                      className={cn(
                        'px-3 py-1.5 rounded-lg text-xs font-medium transition-all',
                        selectedTone === t.id
                          ? 'bg-accent-green-110/15 text-accent-green-110 ring-1 ring-accent-green-110'
                          : 'bg-white-5 text-white-60 hover:bg-white-10'
                      )}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Goal selector — inline */}
              <div className="flex items-center gap-3">
                <span className="text-xs font-medium text-white-60 w-16 flex-shrink-0">Goal</span>
                <div className="flex gap-1.5">
                  {GOAL_OPTIONS.map((g) => (
                    <button
                      key={g.id}
                      onClick={() => setSelectedGoal(g.id)}
                      className={cn(
                        'px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5',
                        selectedGoal === g.id
                          ? 'bg-accent-green-110/15 text-accent-green-110 ring-1 ring-accent-green-110'
                          : 'bg-white-5 text-white-60 hover:bg-white-10'
                      )}
                    >
                      <g.icon className="w-3 h-3" />
                      {g.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Channel pills — inline */}
              <div className="flex items-center gap-3">
                <span className="text-xs font-medium text-white-60 w-16 flex-shrink-0">Channels</span>
                <div className="flex flex-wrap gap-1.5">
                  {ALL_CHANNELS.map((ch) => (
                    <button
                      key={ch.id}
                      onClick={() => toggleChannel(ch.id)}
                      className={cn(
                        'px-3 py-1 rounded-full text-[11px] font-medium transition-all',
                        selectedChannels.includes(ch.id)
                          ? 'bg-accent-green-110/15 text-accent-green-110 ring-1 ring-accent-green-110'
                          : 'bg-white-5 text-white-40 hover:bg-white-10'
                      )}
                    >
                      {ch.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </details>
        )}

        {/* Live crawl feed — collapsible */}
        {crawlPages.length > 0 && (
          <details open={!crawlDone} className="group/crawl">
            <summary className="text-xs text-white-60 cursor-pointer hover:text-white-70 transition-colors select-none flex items-center gap-1.5 list-none [&::-webkit-details-marker]:hidden">
              <ChevronRight className="w-3 h-3 text-white-40 transition-transform group-open/crawl:rotate-90" />
              <Globe className="w-3 h-3 text-accent-green-110" />
              {crawlDone ? `${crawlPages.length} pages explored` : 'Exploring pages...'}
            </summary>
            <div className="space-y-1 max-h-[200px] overflow-y-auto pr-1 mt-2">
              {crawlPages.map((page, i) => (
                <div
                  key={page.url}
                  className="flex items-center gap-2 py-1.5 px-3 rounded-lg bg-sp-card animate-in fade-in slide-in-from-left-2 duration-200"
                  style={{ animationDelay: `${i * 50}ms` }}
                >
                  <Globe className="w-3 h-3 text-accent-green-110 flex-shrink-0" />
                  <span className="text-xs text-white-70 truncate flex-1">
                    {page.title || shortenUrl(page.url)}
                  </span>
                  <span className="text-[10px] text-white-50 flex-shrink-0 font-mono">
                    {page.pageNum}/{page.totalExpected}
                  </span>
                </div>
              ))}
            </div>
          </details>
        )}

        {/* Uploaded documents — collapsible */}
        {uploadedDocNames.length > 0 && (
          <details open className="group/docs">
            <summary className="text-xs text-white-60 cursor-pointer hover:text-white-70 transition-colors select-none flex items-center gap-1.5 list-none [&::-webkit-details-marker]:hidden">
              <ChevronRight className="w-3 h-3 text-white-40 transition-transform group-open/docs:rotate-90" />
              <FileText className="w-3 h-3 text-accent-green-110" />
              {uploadedDocNames.length} document{uploadedDocNames.length !== 1 ? 's' : ''} analyzed
            </summary>
            <div className="space-y-1 max-h-[200px] overflow-y-auto pr-1 mt-2">
              {uploadedDocNames.map((name, i) => (
                <div
                  key={`doc-${i}`}
                  className="flex items-center gap-2 py-1.5 px-3 rounded-lg bg-sp-card animate-in fade-in slide-in-from-left-2 duration-200"
                  style={{ animationDelay: `${i * 50}ms` }}
                >
                  <FileText className="w-3 h-3 text-accent-green-110 flex-shrink-0" />
                  <span className="text-xs text-white-70 truncate flex-1">{name}</span>
                  <Check className="w-3 h-3 text-accent-green-110 flex-shrink-0" />
                </div>
              ))}
            </div>
          </details>
        )}

        {/* Business data items — collapsible */}
        {extractedDataItems.length > 0 && (
          <details open={stages.extractingData === 'active'} className="group/data">
            <summary className="text-xs text-white-60 cursor-pointer hover:text-white-70 transition-colors select-none flex items-center gap-1.5 list-none [&::-webkit-details-marker]:hidden">
              <ChevronRight className="w-3 h-3 text-white-40 transition-transform group-open/data:rotate-90" />
              <Database className="w-3 h-3 text-accent-green-110" />
              {stages.extractingData === 'done' || stages.importing === 'done'
                ? `${extractedDataItems.length} ${extractedDataItems.length !== 1 ? bdLabels.itemPlural.toLowerCase() : bdLabels.itemSingular.toLowerCase()} found`
                : `Extracting ${bdLabels.itemPlural.toLowerCase()}...`}
            </summary>
            <div className="space-y-1 max-h-[200px] overflow-y-auto pr-1 mt-2">
              {extractedDataItems.map((item, i) => (
                <div
                  key={`data-${i}`}
                  className="flex items-center gap-2 py-1.5 px-3 rounded-lg bg-sp-card animate-in fade-in slide-in-from-left-2 duration-200"
                  style={{ animationDelay: `${i * 30}ms` }}
                >
                  <span className="text-[10px] text-accent-green-110 font-medium flex-shrink-0 px-1.5 py-0.5 rounded bg-accent-green-110/10 uppercase tracking-wide">
                    {item.type.replace(/_/g, ' ')}
                  </span>
                  <span className="text-xs text-white-70 truncate flex-1">
                    {item.title}
                  </span>
                </div>
              ))}
            </div>
          </details>
        )}

        {/* Continue button — appears when all stages are done */}
        {allDone && (
          <button
            onClick={() => setStep(2)}
            className="w-full px-6 py-4 rounded-2xl bg-accent-green-110 text-sp-surface font-semibold text-base flex items-center justify-center gap-2 hover:bg-accent-green-120 transition-colors mt-4 shadow-glow-green animate-in fade-in slide-in-from-bottom-2 duration-300"
          >
            Connect Your Channels
            <ArrowRight className="w-5 h-5" />
          </button>
        )}

        {/* Error recovery */}
        {error && !allDone && (
          <button
            onClick={() => handleFinish()}
            className="w-full px-6 py-3 rounded-2xl bg-white-10 text-white-100 font-semibold text-sm flex items-center justify-center gap-2 hover:bg-white-15 transition-colors mt-2"
          >
            Go to Dashboard
            <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Right panel — Live Preview */}
      <div className="space-y-4">
        <p className="text-xs font-semibold text-white-60 uppercase tracking-wider">Live preview</p>

        {/* Brand card — shows as soon as brand:done fires */}
        {(() => {
          const brand = analyzeResult?.brandData ?? earlyBrandData;
          if (brand) {
            return (
              <div className="p-5 rounded-2xl space-y-3 bg-sp-card border border-white-15 animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-accent-green-110/20 flex items-center justify-center flex-shrink-0 overflow-hidden">
                    {brand.logoUrl ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={brand.logoUrl} alt={brand.name} className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-sm font-bold text-accent-green-110">
                        {brand.name?.[0]?.toUpperCase() || '?'}
                      </span>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-lg font-bold text-white truncate">
                      {brand.name}
                    </h3>
                    {brand.industry && (
                      <span className="text-xs text-white-60">
                        {brand.industry}
                      </span>
                    )}
                  </div>
                </div>
                <p className="text-sm text-white-70 leading-relaxed line-clamp-3">
                  {brand.description}
                </p>
              </div>
            );
          }
          return (
            <div className="p-5 rounded-2xl space-y-3 bg-sp-card border border-white-15 animate-pulse">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-white-10" />
                <div className="flex-1 space-y-2">
                  <div className="h-4 w-40 bg-white-10 rounded" />
                  <div className="h-3 w-24 bg-white-10/60 rounded" />
                </div>
              </div>
              <div className="h-3 w-full bg-white-10 rounded" />
              <div className="h-3 w-3/4 bg-white-10/60 rounded" />
            </div>
          );
        })()}

        {/* Brand discovery highlights */}
        {analyzeResult && (
          <div className="p-4 rounded-2xl bg-sp-card border border-white-15 space-y-3 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <p className="text-xs font-semibold text-white-60 uppercase tracking-wider">What we discovered</p>
            <div className="flex flex-wrap gap-2">
              {analyzeResult.voiceData.tone && (
                <span className="px-2.5 py-1 rounded-full bg-accent-green-110/15 text-accent-green-110 text-xs font-medium">
                  {analyzeResult.voiceData.tone} voice
                </span>
              )}
              {analyzeResult.brandData.audience && (
                <span className="px-2.5 py-1 rounded-full bg-white-10 text-white-70 text-xs truncate max-w-[200px]">
                  {analyzeResult.brandData.audience}
                </span>
              )}
              {selectedChannels.slice(0, 3).map((ch) => {
                const chColors = CHANNEL_COLORS[ch] || { badge: 'bg-white-10 text-white-60' };
                return (
                  <span key={ch} className={cn('px-2.5 py-1 rounded-full text-xs font-medium', chColors.badge)}>
                    {ALL_CHANNELS.find((c) => c.id === ch)?.label || ch}
                  </span>
                );
              })}
            </div>
            {extractedDataItems.length > 0 && (
              <div className="flex items-center gap-2 pt-1">
                <Check className="w-3.5 h-3.5 text-accent-green-110 flex-shrink-0" />
                <p className="text-xs text-white-70">
                  {extractedDataItems.length} {extractedDataItems.length !== 1 ? bdLabels.itemPlural.toLowerCase() : bdLabels.itemSingular.toLowerCase()} found
                </p>
              </div>
            )}
          </div>
        )}

        {/* Next steps hint */}
        {allDone && (
          <div className="p-4 rounded-2xl bg-accent-green-110/5 border border-accent-green-110/20 text-center space-y-2 animate-in fade-in duration-300">
            <p className="text-sm font-medium text-accent-green-110">Ready to continue</p>
            <p className="text-xs text-white-50">Connect your channels next, then we&apos;ll generate personalized content.</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Helpers ──────────────────────────────────────────────────────────────

function StageRow({
  status,
  activeLabel,
  doneLabel,
  activeHint,
}: {
  status: StageStatus | 'skipped';
  activeLabel: string;
  doneLabel: string;
  activeHint?: string;
}) {
  return (
    <div className="flex items-start gap-3">
      <div
        className={cn(
          'w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 transition-all mt-0.5',
          status === 'done' && 'bg-accent-green-110',
          status === 'active' && 'bg-accent-green-110/20',
          status === 'pending' && 'bg-white-10'
        )}
      >
        {status === 'done' && <Check className="w-3.5 h-3.5 text-sp-surface" />}
        {status === 'active' && <Loader2 className="w-3.5 h-3.5 text-accent-green-110 animate-spin" />}
      </div>
      <div className="min-w-0">
        <span
          className={cn(
            'text-sm transition-colors',
            status === 'done' && 'text-white-100',
            status === 'active' && 'text-white-100 font-medium',
            status === 'pending' && 'text-white-50'
          )}
        >
          {status === 'done' ? doneLabel : activeLabel}
        </span>
        {status === 'active' && activeHint && (
          <p className="text-xs text-white-60 mt-0.5">
            {activeHint}
          </p>
        )}
      </div>
    </div>
  );
}

function mapToneToOption(tone: string): string {
  const lower = tone.toLowerCase();
  if (lower.includes('bold') || lower.includes('edgy') || lower.includes('provocative')) return 'bold';
  if (lower.includes('conversational') || lower.includes('casual') || lower.includes('friendly')) return 'conversational';
  return 'professional';
}

function shortenUrl(url: string): string {
  try {
    const u = new URL(url);
    return u.pathname === '/' ? u.hostname : `${u.hostname}${u.pathname}`;
  } catch {
    return url;
  }
}

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function getScheduleTime(index: number): { iso: string; label: string } {
  const date = new Date();
  date.setDate(date.getDate() + 1 + index); // tomorrow + index
  date.setHours(10, 0, 0, 0);
  const iso = date.toISOString();
  const label = date.toLocaleDateString(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  }) + ' at 10:00 AM';
  return { iso, label };
}
