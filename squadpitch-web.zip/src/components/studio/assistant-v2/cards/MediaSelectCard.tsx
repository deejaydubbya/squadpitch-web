'use client';

import { useMemo, useState, useCallback } from 'react';
import { ImageIcon } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAssets, useChannelSettings, type Channel, type MediaAsset } from '@/hooks/useSquadpitch';
import { useCampaignIntelligence } from '@/hooks/useCampaignIntelligence';
import type { AssistantAction, AssistantSessionState } from '@/lib/assistant/types';
import { ImagePreviewModal } from './ImagePreviewModal';
import type { SelectableImage, TabId } from './media/types';
import { SelectionStrip } from './media/SelectionStrip';
import { MediaTabContext } from './media/MediaTabContext';
import { MediaTabRecent } from './media/MediaTabRecent';
import { MediaTabLibrary } from './media/MediaTabLibrary';
import { MediaTabUpload } from './media/MediaTabUpload';

interface Props {
  session: AssistantSessionState;
  clientId: string;
  onSelection: (action: AssistantAction | AssistantAction[], confirmationText: string) => void;
}

interface TabDef {
  id: TabId;
  label: string;
}

function resolveTabs(session: AssistantSessionState): TabDef[] {
  const tabs: TabDef[] = [];

  // Context tab — only when there's relevant context
  const hasPropertyContext = session.mode === 'campaign' && !!session.propertyData;
  const hasDataItemContext = session.quickPostSource === 'data' && !!session.quickPostDataItemId;

  if (hasPropertyContext) {
    tabs.push({ id: 'context', label: 'Property Photos' });
  } else if (hasDataItemContext) {
    tabs.push({ id: 'context', label: 'Item Media' });
  }

  tabs.push({ id: 'recent', label: 'Recent' });
  tabs.push({ id: 'library', label: 'Library' });
  tabs.push({ id: 'upload', label: 'Upload & Import' });

  return tabs;
}

function resolveDefaultTab(tabs: TabDef[]): TabId {
  return tabs[0]?.id ?? 'recent';
}

export function MediaSelectCard({ session, clientId, onSelection }: Props) {
  const { data: assets, isLoading } = useAssets(clientId, { status: 'READY', assetType: 'image' });
  const { data: channelSettings } = useChannelSettings(clientId);

  const connectedChannels: Channel[] = useMemo(() => {
    if (!channelSettings) return [];
    return channelSettings.filter((cs) => cs.isEnabled).map((cs) => cs.channel);
  }, [channelSettings]);

  const { mediaRec } = useCampaignIntelligence(session, connectedChannels, assets);

  // Build priority score map from intelligence
  const priorityScoreMap = useMemo(() => {
    const map = new Map<string, number>();
    if (mediaRec?.prioritized) {
      for (const item of mediaRec.prioritized) {
        map.set(item.id, item.score);
      }
    }
    return map;
  }, [mediaRec]);

  // Tab resolution
  const tabs = useMemo(() => resolveTabs(session), [session]);
  const [activeTab, setActiveTab] = useState<TabId>(() => resolveDefaultTab(tabs));

  // Selection state
  const [selected, setSelected] = useState<Set<string>>(() => new Set(session.selectedMediaIds));
  const [heroId, setHeroId] = useState<string | null>(session.heroImageId);
  const [previewImage, setPreviewImage] = useState<SelectableImage | null>(null);

  // Image registry — deduped from all tabs
  const [imageRegistry, setImageRegistry] = useState<Map<string, SelectableImage>>(new Map());
  const allImages = useMemo(() => Array.from(imageRegistry.values()), [imageRegistry]);

  const handleImagesAvailable = useCallback((images: SelectableImage[]) => {
    setImageRegistry((prev) => {
      const next = new Map(prev);
      let changed = false;
      for (const img of images) {
        if (!next.has(img.id)) {
          next.set(img.id, img);
          changed = true;
        }
      }
      return changed ? next : prev;
    });
  }, []);

  // Auto-select context images on first render only — skip if user already went through media step
  const [autoSelected, setAutoSelected] = useState(
    () => session.mediaAcknowledged || session.selectedMediaIds.length > 0
  );
  const handleContextImagesAvailable = useCallback((images: SelectableImage[]) => {
    handleImagesAvailable(images);
    if (!autoSelected && images.length > 0 && selected.size === 0) {
      setAutoSelected(true);
      setSelected(new Set(images.map((img) => img.id)));
    }
  }, [handleImagesAvailable, autoSelected, selected.size]);

  // Selection actions
  const toggle = useCallback((id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const toggleHero = useCallback((id: string) => {
    setHeroId((prev) => (prev === id ? null : id));
  }, []);

  const handleSelectAll = useCallback((ids: string[]) => {
    setSelected((prev) => {
      const next = new Set(prev);
      ids.forEach((id) => next.add(id));
      return next;
    });
  }, []);

  const handleClearIds = useCallback((ids: string[]) => {
    const idSet = new Set(ids);
    setSelected((prev) => {
      const next = new Set(prev);
      idSet.forEach((id) => next.delete(id));
      return next;
    });
  }, []);

  const handleRemove = useCallback((id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      next.delete(id);
      return next;
    });
  }, []);

  // Upload handler — auto-selects uploaded images
  const handleImageUploaded = useCallback((image: SelectableImage) => {
    setImageRegistry((prev) => {
      const next = new Map(prev);
      next.set(image.id, image);
      return next;
    });
    setSelected((prev) => {
      const next = new Set(prev);
      next.add(image.id);
      return next;
    });
  }, []);

  // Build confirmation text with source breakdown
  const buildConfirmationText = (): string => {
    const selectedImages = allImages.filter((img) => selected.has(img.id));
    const bySource: Record<string, number> = {};
    for (const img of selectedImages) {
      bySource[img.source] = (bySource[img.source] ?? 0) + 1;
    }

    const total = selectedImages.length;
    if (total === 0) return 'No images selected';

    const parts: string[] = [];
    if (bySource.property) parts.push(`${bySource.property} property`);
    if (bySource.item) parts.push(`${bySource.item} data item`);
    if (bySource.library) parts.push(`${bySource.library} media library`);
    if (bySource.recent) parts.push(`${bySource.recent} recent`);
    if (bySource.upload) parts.push(`${bySource.upload} uploaded`);

    const heroSuffix = heroId ? ' \u00b7 hero set' : '';
    return `${total} image${total !== 1 ? 's' : ''} selected (${parts.join(', ')})${heroSuffix}`;
  };

  const confirm = () => {
    // Batch all actions into a single call so handleCardSelection advances only once
    const actions: AssistantAction[] = [];

    // Hero image if changed
    if (heroId !== session.heroImageId) {
      actions.push({ type: 'SET_HERO_IMAGE', payload: heroId });
    }

    // Store ALL selected IDs (including synthetic property_img_*/item_img_*).
    // Synthetic IDs are filtered at API boundaries (save, generation) not here.
    const allSelectedIds = Array.from(selected);
    if (allSelectedIds.length > 0) {
      actions.push({ type: 'SET_MEDIA', payload: allSelectedIds });
    } else {
      actions.push({ type: 'SET_MEDIA', payload: [] });
    }

    const text = allSelectedIds.length > 0
      ? buildConfirmationText()
      : 'No images selected';

    onSelection(actions, text);
  };

  const skip = () => {
    onSelection(
      { type: 'SET_MEDIA_ACKNOWLEDGED' },
      'Skipped \u2014 AI will generate without specific images'
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-4">
        <div className="w-5 h-5 border-2 border-white-20 border-t-accent-green-110 rounded-full animate-spin" />
      </div>
    );
  }

  const hasContextTab = tabs.some((t) => t.id === 'context');

  return (
    <div className="space-y-3">
      {/* Selection strip */}
      <SelectionStrip
        allImages={allImages}
        selected={selected}
        heroId={heroId}
        onRemove={handleRemove}
        onToggleHero={toggleHero}
      />

      {/* Tab bar */}
      <div className="flex gap-1 overflow-x-auto pb-0.5">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={cn(
              'px-2.5 py-1 rounded-full text-[10px] font-medium whitespace-nowrap transition-colors',
              activeTab === tab.id
                ? 'bg-accent-green-110 text-sp-bg'
                : 'bg-white-5 text-white-40 hover:bg-white-10 hover:text-white-60'
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      {activeTab === 'context' && hasContextTab && (
        <MediaTabContext
          session={session}
          clientId={clientId}
          selected={selected}
          heroId={heroId}
          onToggle={toggle}
          onToggleHero={toggleHero}
          onPreview={setPreviewImage}
          priorityScoreMap={priorityScoreMap}
          onSelectAll={handleSelectAll}
          onClearIds={handleClearIds}
          onImagesAvailable={handleContextImagesAvailable}
        />
      )}

      {activeTab === 'recent' && (
        <MediaTabRecent
          clientId={clientId}
          selected={selected}
          heroId={heroId}
          onToggle={toggle}
          onToggleHero={toggleHero}
          onPreview={setPreviewImage}
          priorityScoreMap={priorityScoreMap}
          onImagesAvailable={handleImagesAvailable}
        />
      )}

      {activeTab === 'library' && (
        <MediaTabLibrary
          clientId={clientId}
          selected={selected}
          heroId={heroId}
          onToggle={toggle}
          onToggleHero={toggleHero}
          onPreview={setPreviewImage}
          priorityScoreMap={priorityScoreMap}
          mediaRec={mediaRec}
          onImagesAvailable={handleImagesAvailable}
        />
      )}

      {activeTab === 'upload' && (
        <MediaTabUpload
          clientId={clientId}
          onImageUploaded={handleImageUploaded}
        />
      )}

      {/* Empty state — only show if no images at all across tabs */}
      {allImages.length === 0 && activeTab !== 'upload' && (
        <div className="flex flex-col items-center py-4 text-center">
          <ImageIcon className="w-5 h-5 text-white-30 mb-2" />
          <p className="text-xs text-white-40">No images available. Upload some or skip to generate without media.</p>
        </div>
      )}

      {/* Confirm / Skip buttons */}
      <div className="flex items-center gap-2 flex-wrap">
        <button
          onClick={confirm}
          disabled={selected.size === 0}
          className={cn(
            'px-3 py-1.5 rounded-lg text-xs font-medium transition-colors',
            selected.size > 0
              ? 'bg-accent-green-110 text-sp-bg hover:bg-accent-green-110/90'
              : 'bg-white-10 text-white-40 cursor-not-allowed'
          )}
        >
          {selected.size > 0 ? `Confirm (${selected.size})` : 'Select images'}
        </button>

        <button
          onClick={skip}
          className="px-3 py-1.5 rounded-lg text-xs font-medium text-white-40 hover:text-white-100 hover:bg-white-5 transition-colors"
        >
          Skip
        </button>
      </div>

      {/* Selection summary */}
      {selected.size > 0 && (
        <p className="text-[10px] text-white-40">
          {buildConfirmationText()}
        </p>
      )}

      {/* Preview Modal */}
      {previewImage && (
        <ImagePreviewModal
          image={previewImage}
          isHero={heroId === previewImage.id}
          onHeroToggle={() => toggleHero(previewImage.id)}
          onClose={() => setPreviewImage(null)}
        />
      )}
    </div>
  );
}
