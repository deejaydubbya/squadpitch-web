import { apiFetch } from '@/lib/apiFetch';

type PropertyImageInput = string | { url?: string; label?: string };

interface NormalizeResult {
  syntheticToReal: Map<string, string>;
  allRealIds: string[];
  errors: Array<{ syntheticId: string; message: string }>;
}

/**
 * Resolve the URL from a property image entry that may be a plain string or an object.
 */
function resolveImageUrl(entry: PropertyImageInput): string | undefined {
  if (typeof entry === 'string') return entry || undefined;
  return entry?.url || undefined;
}

function resolveImageLabel(entry: PropertyImageInput, fallbackIndex: number): string {
  if (typeof entry === 'string') return `property_photo_${fallbackIndex}`;
  return entry?.label || `property_photo_${fallbackIndex}`;
}

/**
 * Convert synthetic property_img_N and item_img_N IDs to real MediaAsset IDs
 * by uploading the source URL via the upload-from-url endpoint.
 * Serial uploads to avoid rate limits, best-effort on individual failures.
 *
 * propertyImages accepts both string[] and {url, label}[] formats.
 */
export async function normalizeAssignedMediaForSave(
  clientId: string,
  syntheticIds: string[],
  propertyImages: PropertyImageInput[],
  dataItemImages?: PropertyImageInput[]
): Promise<NormalizeResult> {
  const syntheticToReal = new Map<string, string>();
  const errors: NormalizeResult['errors'] = [];

  for (const synId of syntheticIds) {
    // Match property_img_N
    const propMatch = synId.match(/^property_img_(\d+)$/);
    if (propMatch) {
      const idx = parseInt(propMatch[1], 10);
      const entry = propertyImages[idx];
      if (!entry) {
        errors.push({ syntheticId: synId, message: 'No property image at this index' });
        continue;
      }
      const url = resolveImageUrl(entry);
      if (!url) {
        errors.push({ syntheticId: synId, message: 'No URL found for property image' });
        continue;
      }

      try {
        const result = await apiFetch<{ id: string }>(
          `workspaces/${clientId}/assets/upload-from-url`,
          {
            method: 'POST',
            body: JSON.stringify({ url, filename: resolveImageLabel(entry, idx) }),
          }
        );
        syntheticToReal.set(synId, result.id);
      } catch (err) {
        errors.push({
          syntheticId: synId,
          message: err instanceof Error ? err.message : 'Upload failed',
        });
      }
      continue;
    }

    // Match item_img_N
    const itemMatch = synId.match(/^item_img_(\d+)$/);
    if (itemMatch) {
      const idx = parseInt(itemMatch[1], 10);
      const items = dataItemImages ?? [];
      const entry = items[idx];
      if (!entry) {
        errors.push({ syntheticId: synId, message: 'No data item image at this index' });
        continue;
      }
      const url = resolveImageUrl(entry);
      if (!url) {
        errors.push({ syntheticId: synId, message: 'No URL found for data item image' });
        continue;
      }

      try {
        const result = await apiFetch<{ id: string }>(
          `workspaces/${clientId}/assets/upload-from-url`,
          {
            method: 'POST',
            body: JSON.stringify({ url, filename: `data_item_photo_${idx}` }),
          }
        );
        syntheticToReal.set(synId, result.id);
      } catch (err) {
        errors.push({
          syntheticId: synId,
          message: err instanceof Error ? err.message : 'Upload failed',
        });
      }
      continue;
    }
  }

  const allRealIds = Array.from(syntheticToReal.values());
  return { syntheticToReal, allRealIds, errors };
}

/**
 * Normalize quick post media for save: keeps real MediaAsset IDs as-is,
 * converts synthetic property_img_N / item_img_N to real assets via upload-from-url.
 * Returns only real MediaAsset IDs ready to attach.
 */
export async function normalizeQuickPostMediaForSave({
  clientId,
  selectedMediaIds,
  propertyData,
  dataItemImages,
}: {
  clientId: string;
  selectedMediaIds: string[];
  propertyData?: Record<string, unknown> | null;
  dataItemImages?: PropertyImageInput[];
}): Promise<{ realMediaAssetIds: string[]; errors: NormalizeResult['errors'] }> {
  const realIds: string[] = [];
  const syntheticIds: string[] = [];

  for (const id of selectedMediaIds) {
    if (id.startsWith('property_img_') || id.startsWith('item_img_')) {
      syntheticIds.push(id);
    } else {
      realIds.push(id);
    }
  }

  if (syntheticIds.length === 0) {
    return { realMediaAssetIds: realIds, errors: [] };
  }

  // Resolve property images from propertyData
  const rawPropImages = propertyData?.images;
  const propertyImages: PropertyImageInput[] = Array.isArray(rawPropImages)
    ? (rawPropImages as PropertyImageInput[])
    : [];

  const result = await normalizeAssignedMediaForSave(
    clientId,
    syntheticIds,
    propertyImages,
    dataItemImages
  );

  return {
    realMediaAssetIds: [...realIds, ...result.allRealIds],
    errors: result.errors,
  };
}

/**
 * Replace synthetic IDs in an array with their real counterparts.
 * IDs not found in the map are filtered out.
 */
export function replaceSyntheticIds(
  ids: string[],
  syntheticToReal: Map<string, string>
): string[] {
  return ids
    .map((id) => syntheticToReal.get(id) ?? id)
    .filter((id) => !id.startsWith('property_img_') && !id.startsWith('item_img_'));
}
