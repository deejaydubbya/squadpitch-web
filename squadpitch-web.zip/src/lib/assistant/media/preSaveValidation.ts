/**
 * Pre-save validation for campaigns.
 * Catches issues that would cause data loss or broken posts before saving.
 */

export type IssueSeverity = 'error' | 'warning';

export interface ValidationIssue {
  severity: IssueSeverity;
  message: string;
}

const MEDIA_REQUIRED_CHANNELS = new Set(['INSTAGRAM', 'TIKTOK', 'YOUTUBE']);

interface PostForValidation {
  body: string;
  channel: string;
  assignedImageIds: string[];
  label?: string;
  campaignDay?: number;
}

export function validateCampaignBeforeSave(posts: PostForValidation[]): ValidationIssue[] {
  const issues: ValidationIssue[] = [];

  // Check for remaining synthetic IDs
  const syntheticPosts = posts.filter((p) =>
    p.assignedImageIds.some((id) => id.startsWith('property_img_') || id.startsWith('item_img_'))
  );
  if (syntheticPosts.length > 0) {
    issues.push({
      severity: 'warning',
      message: `${syntheticPosts.length} post(s) still have unconverted property images — these will be removed on save`,
    });
  }

  // Check for media-required channels without media
  const missingMedia = posts.filter(
    (p) => MEDIA_REQUIRED_CHANNELS.has(p.channel) && p.assignedImageIds.length === 0
  );
  if (missingMedia.length > 0) {
    issues.push({
      severity: 'warning',
      message: `${missingMedia.length} post(s) on media-required channels (${Array.from(new Set(missingMedia.map((p) => p.channel))).join(', ')}) have no images`,
    });
  }

  // Check for empty body
  const emptyBody = posts.filter((p) => !p.body.trim());
  if (emptyBody.length > 0) {
    issues.push({
      severity: 'error',
      message: `${emptyBody.length} post(s) have empty body text`,
    });
  }

  return issues;
}
