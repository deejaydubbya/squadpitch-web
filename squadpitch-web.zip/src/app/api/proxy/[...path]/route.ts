import { auth0 } from '@/lib/auth0';
import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

// Allow large request bodies for campaign image uploads (base64 payloads)
export const maxDuration = 60;

const API_URL = process.env.SQUADPITCH_API_URL || 'http://localhost:4000';

async function proxy(request: NextRequest, { params }: { params: { path: string[] } }) {
  const path = params.path.join('/');
  const url = `${API_URL}/api/v1/${path}${request.nextUrl.search}`;

  const session = await auth0.getSession(request);
  const token = session?.tokenSet?.accessToken;

  const headers: Record<string, string> = {};
  const contentType = request.headers.get('content-type');
  if (contentType) headers['content-type'] = contentType;
  if (token) headers['authorization'] = `Bearer ${token}`;

  const body = request.method !== 'GET' && request.method !== 'HEAD'
    ? await request.arrayBuffer()
    : undefined;

  const res = await fetch(url, {
    method: request.method,
    headers,
    body: body ? Buffer.from(body) : undefined,
  });

  // Stream SSE responses instead of buffering
  const resContentType = res.headers.get('content-type') || '';
  if (resContentType.includes('text/event-stream') && res.body) {
    return new NextResponse(res.body as unknown as ReadableStream, {
      status: res.status,
      headers: {
        'content-type': 'text/event-stream',
        'cache-control': 'no-cache, no-transform',
        'x-accel-buffering': 'no',
      },
    });
  }

  const responseBody = await res.arrayBuffer();
  return new NextResponse(responseBody, {
    status: res.status,
    headers: {
      'content-type': resContentType || 'application/json',
    },
  });
}

export const GET = proxy;
export const POST = proxy;
export const PUT = proxy;
export const PATCH = proxy;
export const DELETE = proxy;
